/**
 * generateMatpassPDF.ts
 *
 * Generates a Material Pass PDF for a single MATERIAL_PASS record
 * + all its STOCK_INOUT_LIST entries (linked via MAT_PASS_ID).
 *
 * API endpoints:
 *   GET /api/matpass/{id}            → MatpassRow
 *   GET /api/stocks/matpass/{id}     → StockMovementRow[]
 *   GET /api/customers/{id}          → CustomerDTO (ID parsed from party string)
 *
 * Party name format: "<customerId>-<n>", e.g. "40-xyz pvt ltd"
 * Logo: /images/logo/logo.jpg (served from public/)
 */

import jsPDF from "jspdf";
import axiosInstance from "../../utils/axiosInstance";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MatpassRow {
  id:              string | number;
  inOrOut:         string;   // 'IN' | 'OUT'
  party:           string;
  date:            string;
  contactPerson?:  string;
  discription?:    string;   // intentional typo matches DB column
  fileRef?:        string;
  status?:         string | number;
}

export interface StockMovementRow {
  id?:                      string | number;
  stockItemId?:             string | number;
  stockItemName?:           string;
  stockDate?:               string;
  stockDescription?:        string;
  stockInOut:               string;   // 'IN' | 'OUT'
  stockQuantity:            string | number;
  stockReturnOrNonReturn?:  string;   // 'RETURN' | 'NON-RETURN'
  stockParty?:              string;
  matPassId?:               string | number;
  status?:                  string | number;
}

export interface CustomerRow {
  id?:               string | number;
  name?:             string;
  gst?:              string;
  cin?:              string;
  pan?:              string;
  buyerAddress1?:    string;
  buyerAddress2?:    string;
  buyerAddress3?:    string;
  shippingAddress1?: string;
  shippingAddress2?: string;
  shippingAddress3?: string;
}

// ─── Company constants ────────────────────────────────────────────────────────

const COMPANY = {
  name:    "MosIC Solutions Pvt Ltd",
  address: "No 5 Second A Cross Rajashree Layout, Munnekolala, Marathahalli,",
  city:    "Bangalore 560037 Karnataka",
  gst:     "GST No: 29AAICM6836G1Z3",
  pan:     "PAN No: AAICM6836G",
  cin:     "CIN No: U72200KA2013PTC069886",
  website: "Website: www.mosics.com",
  phone:   "Phone: +91-9980914698",
  email:   "Email: salesandsupport@mosics.com",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmt   = (v: unknown) => (v != null && String(v).trim() ? String(v).trim() : "—");
const today = () =>
  new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });

const loadImage = (src: string): Promise<HTMLImageElement> =>
  new Promise((resolve, reject) => {
    const img = new Image();
    img.onload  = () => resolve(img);
    img.onerror = () => reject();
    img.src = src;
  });

// ─── Main export ──────────────────────────────────────────────────────────────

export async function generateMatpassPDF(
  docId: string | number,
  prefetchedRow?: MatpassRow,
  prefetchedMovements?: StockMovementRow[],
  prefetchedCustomer?: CustomerRow,
): Promise<void> {

  let row:       MatpassRow;
  let movements: StockMovementRow[];
  let customer:  CustomerRow = {};

  if (prefetchedRow && prefetchedMovements) {
    row       = prefetchedRow;
    movements = prefetchedMovements;
    customer  = prefetchedCustomer ?? {};
  } else {
    let rowRes, movRes;
    try {
      [rowRes, movRes] = await Promise.all([
        axiosInstance.get(`/api/matpass/${docId}`),
        axiosInstance.get(`/api/stocks/matpass/${docId}`),
      ]);
    } catch (err: unknown) {
      const status = (err as { response?: { status?: number } })?.response?.status;
      if (status === 403) {
        throw new Error(
          `Access denied fetching Material Pass #${docId}. ` +
          `Ask your admin to grant the required role in Spring Security.`
        );
      }
      if (status === 401) throw new Error(`Session expired. Please log out and log in again.`);
      if (status === 404) throw new Error(`Material Pass #${docId} was not found on the server.`);
      throw err;
    }
    row = rowRes.data as MatpassRow;
    const rawMov = Array.isArray(movRes.data)
      ? movRes.data
      : (movRes.data?.items ?? movRes.data?.data ?? []);
    movements = rawMov as StockMovementRow[];

    if (row.party) {
      try {
        const customerId = parseInt(String(row.party).split("-")[0], 10);
        if (!isNaN(customerId)) {
          const custRes = await axiosInstance.get(`/api/customers/${customerId}`);
          customer = custRes.data as CustomerRow;
        }
      } catch {
        // best-effort — PDF still generates without customer details
      }
    }
  }

  // ── Preload logo ───────────────────────────────────────────────────────────
  let logoImg: HTMLImageElement | null = null;
  try {
    logoImg = await loadImage("/images/logo/logo.jpg");
  } catch {
    // logo missing — will leave space blank
  }

  // ── PDF setup ──────────────────────────────────────────────────────────────
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw  = doc.internal.pageSize.getWidth();
  const ph  = doc.internal.pageSize.getHeight();
  const ml  = 14;
  const mr  = 14;
  const cw  = pw - ml - mr;
  let   y   = 0;
  let   pageNum = 1;

  const inOut      = String(row.inOrOut || "").toUpperCase();
  const titleColor: [number, number, number] = inOut === "IN" ? [140, 60, 0] : [80, 0, 100];

  // ── Stock movements table columns ──────────────────────────────────────────
  const cols = [
    { label: "#",              w: 8  },
    { label: "ITEM",           w: 38 },
    { label: "DATE",           w: 24 },
    { label: "IN/OUT",         w: 16 },
    { label: "QTY",            w: 16 },
    { label: "RETURN TYPE",    w: 28 },
    { label: "PARTY",          w: 26 },
    { label: "DESCRIPTION",    w: 26 },
  ];
  const usedW = cols.reduce((s, c) => s + c.w, 0);
  cols[cols.length - 1].w += cw - usedW;

  let tableHeaderDrawn = false;

  const drawMovHeader = () => {
    doc.setFillColor(...titleColor);
    doc.rect(ml, y, cw, 8, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.setTextColor(255, 255, 255);
    let cx = ml;
    cols.forEach((col) => { doc.text(col.label, cx + 1.5, y + 5.5); cx += col.w; });
    y += 8;
  };

  // ── Header ─────────────────────────────────────────────────────────────────
  const drawHeader = () => {
    y = 10;

    if (logoImg) {
      doc.addImage(logoImg, "JPEG", ml, y, 22, 22);
    } else {
      doc.setDrawColor(180, 180, 180);
      doc.setLineWidth(0.4);
      doc.rect(ml, y, 22, 22);
      doc.setFont("helvetica", "italic");
      doc.setFontSize(7);
      doc.setTextColor(180, 180, 180);
      doc.text("LOGO", ml + 5, y + 12);
    }

    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(30, 30, 30);
    doc.text(COMPANY.name, ml + 26, y + 7);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(60, 60, 60);
    doc.text(COMPANY.address, ml + 26, y + 12);
    doc.text(COMPANY.city,    ml + 26, y + 16);

    const rx = pw - mr;
    doc.text(COMPANY.gst,     rx, y + 12, { align: "right" });
    doc.text(COMPANY.pan,     rx, y + 16, { align: "right" });
    doc.text(COMPANY.cin,     ml + 26, y + 20);
    doc.text(COMPANY.website, rx, y + 20, { align: "right" });
    doc.text(`${COMPANY.phone}   ${COMPANY.email}`, ml + 26, y + 24);

    doc.setDrawColor(180, 180, 180);
    doc.setLineWidth(0.4);
    doc.line(ml, y + 26, pw - mr, y + 26);
    y += 30;
  };

  // ── Footer ─────────────────────────────────────────────────────────────────
  const drawFooter = () => {
    const fy = ph - 10;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(140, 140, 140);
    doc.text(`Generated: ${today()}`, ml, fy);
    doc.text(`Page ${pageNum}`, pw / 2, fy, { align: "center" });
    doc.text("MosIC Solutions Pvt Ltd — Confidential", pw - mr, fy, { align: "right" });
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.3);
    doc.line(ml, fy - 3, pw - mr, fy - 3);
  };

  // ── ensureSpace ────────────────────────────────────────────────────────────
  const ensureSpace = (needed: number) => {
    if (y + needed > ph - 18) {
      drawFooter();
      doc.addPage();
      pageNum++;
      drawHeader();
      if (tableHeaderDrawn) {
        drawMovHeader();
      }
    }
  };

  // ═══════════════════════════════════════════════════════════════════════════
  drawHeader();

  // ── Title bar ──────────────────────────────────────────────────────────────
  doc.setFillColor(...titleColor);
  doc.rect(ml, y, cw, 9, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text(`MATERIAL PASS — ${inOut || "RECORD"}`, pw / 2, y + 6.2, { align: "center" });
  y += 13;

  // ── Pass Details section heading ───────────────────────────────────────────
  doc.setFillColor(245, 247, 250);
  doc.rect(ml, y, cw, 7, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(40, 40, 40);
  doc.text("MATERIAL PASS DETAILS", ml + 3, y + 5);
  y += 9;

  // ── Two-column detail block ────────────────────────────────────────────────
  const detailBoxH = 48;
  doc.setDrawColor(220, 220, 220);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw, detailBoxH);
  doc.line(ml + cw / 2, y, ml + cw / 2, y + detailBoxH);

  const col1x  = ml + 2;
  const col2x  = ml + cw / 2 + 2;
  const valOff = 32;

  const detailRow = (cx: number, label: string, value: string, dy: number) => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(90, 90, 90);
    doc.text(`${label}:`, cx, y + dy);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(20, 20, 20);
    const maxW = cw / 2 - valOff - 4;
    const lines = doc.splitTextToSize(value, maxW);
    doc.text(lines[0] ?? "—", cx + valOff, y + dy);
  };

  // Left column
  detailRow(col1x, "Pass ID",        fmt(row.id),           6);
  detailRow(col1x, "Direction",      inOut || "—",           12);
  detailRow(col1x, "Party",          fmt(row.party),         18);
  detailRow(col1x, "Date",           fmt(row.date),          24);
  detailRow(col1x, "Description",    fmt(row.discription),   30);

  // Right column
  detailRow(col2x, "Contact Person", fmt(row.contactPerson), 6);
  detailRow(col2x, "File Reference", fmt(row.fileRef),       12);
  detailRow(col2x, "GST No",         fmt(customer.gst),      18);
  detailRow(col2x, "CIN No",         fmt(customer.cin),      24);
  detailRow(col2x, "PAN No",         fmt(customer.pan),      30);

  // IN/OUT badge
  doc.setFillColor(
    inOut === "IN" ? 220 : 200,
    inOut === "IN" ? 240 : 200,
    inOut === "IN" ? 220 : 240,
  );
  doc.rect(col1x, y + 38, 18, 6, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(
    inOut === "IN" ? 0   : 80,
    inOut === "IN" ? 80  : 0,
    inOut === "IN" ? 0   : 80,
  );
  doc.text(inOut || "—", col1x + 3, y + 43);

  y += detailBoxH + 4;

  // ── Billing / Shipping addresses ───────────────────────────────────────────
  const addrBoxH = 28;
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw / 2, addrBoxH);
  doc.rect(ml + cw / 2, y, cw / 2, addrBoxH);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(80, 80, 80);
  doc.text("BILLING ADDRESS :", ml + 2, y + 5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(20, 20, 20);
  doc.text(fmt(customer.buyerAddress1), ml + 4, y + 11);
  doc.text(fmt(customer.buyerAddress2), ml + 4, y + 16);
  doc.text(fmt(customer.buyerAddress3), ml + 4, y + 21);

  const sx = ml + cw / 2 + 2;
  doc.setFont("helvetica", "bold");
  doc.setTextColor(80, 80, 80);
  doc.text("SHIPPING ADDRESS :", sx, y + 5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(20, 20, 20);
  doc.text(fmt(customer.shippingAddress1), sx + 2, y + 11);
  doc.text(fmt(customer.shippingAddress2), sx + 2, y + 16);
  doc.text(fmt(customer.shippingAddress3), sx + 2, y + 21);
  y += addrBoxH + 4;

  // ── Stock Movements section heading ────────────────────────────────────────
  doc.setFillColor(245, 247, 250);
  doc.rect(ml, y, cw, 7, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(40, 40, 40);
  doc.text(
    `STOCK MOVEMENTS  (${movements.length} record${movements.length !== 1 ? "s" : ""})`,
    ml + 3,
    y + 5,
  );
  y += 9;

  // ── Stock movements table ──────────────────────────────────────────────────
  if (movements.length === 0) {
    doc.setFont("helvetica", "italic");
    doc.setFontSize(9);
    doc.setTextColor(140, 140, 140);
    doc.text("No stock movements linked to this material pass.", ml + 3, y + 5);
    y += 10;
  } else {
    drawMovHeader();
    tableHeaderDrawn = true;

    movements.forEach((mov, idx) => {
      const itemLines  = doc.splitTextToSize(fmt(mov.stockItemName ?? mov.stockItemId), cols[1].w - 3);
      const descLines2 = doc.splitTextToSize(fmt(mov.stockDescription), cols[7].w - 3);
      const rowH = Math.max(8, Math.max(itemLines.length, descLines2.length) * 4.5 + 3);

      ensureSpace(rowH + 2);

      if (idx % 2 === 0) {
        doc.setFillColor(249, 250, 252);
        doc.rect(ml, y, cw, rowH, "F");
      }
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.2);
      doc.rect(ml, y, cw, rowH);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(40, 40, 40);

      let cx = ml;
      doc.text(String(idx + 1), cx + 1.5, y + 5);          cx += cols[0].w;
      doc.text(itemLines, cx + 1.5, y + 5);                 cx += cols[1].w;
      doc.text(fmt(mov.stockDate), cx + 1.5, y + 5);        cx += cols[2].w;

      const movDir = String(mov.stockInOut || "").toUpperCase();
      doc.setTextColor(movDir === "IN" ? 0 : 150, movDir === "IN" ? 120 : 0, movDir === "IN" ? 0 : 120);
      doc.setFont("helvetica", "bold");
      doc.text(movDir || "—", cx + 1.5, y + 5);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(40, 40, 40);
      cx += cols[3].w;

      doc.text(fmt(mov.stockQuantity), cx + 1.5, y + 5);          cx += cols[4].w;
      doc.text(fmt(mov.stockReturnOrNonReturn), cx + 1.5, y + 5);  cx += cols[5].w;
      doc.text(fmt(mov.stockParty), cx + 1.5, y + 5);              cx += cols[6].w;
      doc.text(descLines2, cx + 1.5, y + 5);

      y += rowH;
    });

    tableHeaderDrawn = false;
    y += 4;
  }

  // ── Signature footer ────────────────────────────────────────────────────────
  ensureSpace(26);
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw, 22);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(40, 40, 40);
  doc.text("FOR MOSIC SOLUTIONS PVT LTD", ml + 4, y + 6);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text("AUTHORISED SIGNATURE", ml + 4, y + 18);
  y += 26;

  drawFooter();

  const filename = `MatPass_${row.id}_${inOut}_${(row.party || "party").replace(/[^a-zA-Z0-9]/g, "_").slice(0, 20)}.pdf`;
  doc.save(filename);
}