/**
 * generateAppointmentPDF.ts
 *
 * Generates an Appointment / Offer Letter PDF.
 * Matches the exact layout of PDFDESIGN_APPOINTMENT.java output.
 *
 * Layout (multi-page, A4):
 *   Page 1:
 *     • Top-left  : Company name (large) + address lines below
 *     • Top-right : Company logo placeholder
 *     • Thick horizontal separator line
 *     • Ref No (italic, left) + Date (right)
 *     • "To" / employee address block
 *     • Dear salutation
 *     • "Sub: Letter of Appointment" (centred, large)
 *     • Intro paragraph
 *     • 1.APPOINTMENT
 *     • 2.COMPENSATION
 *     • 3.OTHER BENEFITS
 *   Page 2:
 *     • Logo top-right
 *     • 4.RESPONSIBILITIES
 *     • 5. CONFLICTS OF INTEREST
 *   Page 3:
 *     • Logo top-right
 *     • 6. CONFIDENTIALITY
 *     • 7. ASSIGNMENT OF INTELLECTUAL PROPERTY
 *     • 8. NON-COMPETE
 *     • 9. GENERAL
 *   Page 4:
 *     • Logo top-right
 *     • (continuation of 9. GENERAL point d)
 *     • 10. NOTICE PERIOD
 *     • Closing / Sincerely / Managing Director
 *     • Declaration & Acknowledgment from Employee
 *
 * Usage:
 *   import { generateAppointmentPDF } from "./pdf/generateAppointmentPDF";
 *   generateAppointmentPDF(row, emp, letterDate);
 */

import jsPDF from "jspdf";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface EmpPositionDTO {
  id: number | null;
  empId: number | null;
  epDate: string;
  epEfficientDate: string;
  position: string;
  department: string;
  role: string;
  reportingTo: string;
  empBasic: string;
  empHra: string;
  empAllowance: string;
  empMonthGross: string;
  empCtc: string;
  empTds: string;
  empPt: string;
  empLoans: string;
  activeStatus: string;
  status: string;
}

export interface EmpDTO {
  id: number;
  empName: string;
  empLastName: string;
  empEmail?: string;
  empPhone?: string;
  empMail?: string;
  empPh?: string;
  empAddress1?: string;
  empAddress2?: string;
  empAddress3?: string;
  empDoj?: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const fmtDate = (d: string | undefined | null): string => {
  if (!d) return "";
  const parts = d.includes("-") ? d.split("-") : d.split("/");
  if (parts.length !== 3) return d;
  if (parts[0].length === 2) return d;
  const [y, m, day] = parts;
  return `${day}-${m}-${y}`;
};

const todayDMY = (): string => {
  const n = new Date();
  return `${String(n.getDate()).padStart(2,"0")}-${String(n.getMonth()+1).padStart(2,"0")}-${n.getFullYear()}`;
};

const cur = (v: unknown): string => (parseFloat(String(v ?? 0)) || 0).toFixed(2);

// ─── Page context ─────────────────────────────────────────────────────────────

interface Ctx {
  doc:  jsPDF;
  pw:   number;
  ph:   number;
  ml:   number;       // left margin
  cw:   number;       // content width
  y:    number;       // current y cursor
}

/** Draw the small logo placeholder that appears on pages 2-4 (top-right corner) */
function drawPageLogo(ctx: Ctx): void {
  const { doc, pw, ml } = ctx;
  const lx = pw - ml - 28;
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.rect(lx, 6, 26, 20);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(6);
  doc.setTextColor(160, 160, 160);
  doc.text("LOGO", lx + 8, 18);
}

/** Draw a bold section heading (e.g. "1.APPOINTMENT") */
function secHead(ctx: Ctx, text: string): void {
  const { doc, ml } = ctx;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(20, 20, 20);
  ctx.y += 4;
  doc.text(text, ml, ctx.y);
  ctx.y += 6;
}

/** Wrap and print body text, advancing ctx.y */
function body(ctx: Ctx, text: string, indent = 0, fs = 9): void {
  const { doc, ml, cw } = ctx;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(fs);
  doc.setTextColor(20, 20, 20);
  const lines = doc.splitTextToSize(text, cw - indent) as string[];
  // Page overflow check
  if (ctx.y + lines.length * (fs * 0.35 + 1.5) > ctx.ph - 14) {
    addPage(ctx);
  }
  doc.text(lines, ml + indent, ctx.y);
  ctx.y += lines.length * (fs * 0.35 + 1.5) + 1;
}

/** Add a new page and reset y */
function addPage(ctx: Ctx): void {
  ctx.doc.addPage();
  drawPageLogo(ctx);
  ctx.y = 32;
}

// ─── Main export ──────────────────────────────────────────────────────────────

/**
 * @param row         EmpPositionDTO
 * @param emp         EmpDTO
 * @param letterDate  ISO yyyy-mm-dd; defaults to today
 */
export function generateAppointmentPDF(
  row: EmpPositionDTO,
  emp: EmpDTO,
  letterDate?: string,
): void {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw  = doc.internal.pageSize.getWidth();
  const ph  = doc.internal.pageSize.getHeight();
  const ml  = 15;

  const ctx: Ctx = { doc, pw, ph, ml, cw: pw - ml * 2, y: 0 };

  const date    = fmtDate(letterDate) || todayDMY();
  const effDate = fmtDate(row.epEfficientDate || row.epDate) || date;
  const refNo   = `APP/LTR/${effDate}/${row.empId ?? emp.id}`;
  const empName = `${emp.empName} ${emp.empLastName}`;
  const ctcAnnual = cur(row.empCtc);
  const addr    = [emp.empAddress1, emp.empAddress2, emp.empAddress3].filter(Boolean) as string[];

  const right = pw - ml;

  // ══════════════════════════════════════════════════════════════════
  // PAGE 1
  // ══════════════════════════════════════════════════════════════════

  // ── Company name (large, top-left) ─────────────────────────────────────────
  doc.setFont("helvetica", "bold");
  doc.setFontSize(26);
  doc.setTextColor(20, 20, 20);
  doc.text("MosIC Solutions Pvt Ltd", ml, 16);

  // ── Address lines below company name ──────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(40, 40, 40);
  doc.text("No 5 Second A Cross Rajashree Layout,Munnekolala,Marathahalli,Bangalore 560037.", ml, 22);
  doc.text("Karnataka.Website:www.mosics.com,Phone: +91-9980914698", ml, 27);
  doc.text("Email: salesandsupport@mosics.com.", ml, 32);

  // ── Logo (top-right) ──────────────────────────────────────────────────────
  const lx = pw - ml - 30;
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.rect(lx, 6, 28, 22);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(6.5);
  doc.setTextColor(160, 160, 160);
  doc.text("LOGO", lx + 9, 19);

  // ── Horizontal separator ───────────────────────────────────────────────────
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(1.2);
  doc.line(ml, 38, right, 38);
  // second thin line (the Java draws two consecutive lines)
  doc.setLineWidth(0.4);
  doc.line(ml, 40, right, 40);

  ctx.y = 47;

  // ── Ref No (italic left) + Date (right) ────────────────────────────────────
  doc.setFont("helvetica", "italic");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text(`Ref No:${refNo}`, ml, ctx.y);
  doc.setFont("helvetica", "normal");
  doc.text(`Date : ${date}`, right, ctx.y, { align: "right" });
  ctx.y += 6;

  // ── "To" + employee address ────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);
  doc.text("To ", ml, ctx.y); ctx.y += 5;
  doc.text(`${empName},`, ml, ctx.y); ctx.y += 5;
  addr.forEach((line) => {
    doc.text(line, ml, ctx.y);
    ctx.y += 5;
  });
  ctx.y += 4;

  // ── Dear salutation ────────────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);
  doc.text(`Dear ${empName},`, ml, ctx.y);
  ctx.y += 7;

  // ── "Sub: Letter of Appointment" (centred, large) ─────────────────────────
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(20, 20, 20);
  doc.text("Sub: Letter of Appointment", pw / 2, ctx.y, { align: "center" });
  ctx.y += 8;

  // ── Intro paragraph ────────────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);
  // Java: position + department laid out with spaces between them
  const introLine = `its our pleasure in appointing you in MosIC solution(P)Ltd.,as ${row.position ?? ""}    in   ${row.department ?? ""}`;
  body(ctx, introLine, 4, 9.5);
  body(
    ctx,
    "or in such other capacity the management shall from time to me determine. Please note that the employment terms contained in this letter are subject to the company policy.",
    0, 9.5,
  );
  ctx.y += 2;

  // ══════════════════════════════════════════════════════════════════
  // 1. APPOINTMENT
  // ══════════════════════════════════════════════════════════════════
  secHead(ctx, "1.APPOINTMENT");
  body(ctx, `1.Your date appointment is effective from ${effDate}`, 0, 9.5);
  body(ctx,
    "2.You will be liable to be transferred in such capacity as the company may from time to time determine to any other location, department, function, establishment, or branch of the company or its subsidiary, associate or affiliate Company. In such case you will be governed by the terms and conditions of service applicable to the new assignment.",
    0, 9.5);
  body(ctx, "3.The age of retirement is 58 Years.", 0, 9.5);
  ctx.y += 2;

  // ══════════════════════════════════════════════════════════════════
  // 2. COMPENSATION
  // ══════════════════════════════════════════════════════════════════
  secHead(ctx, "2.COMPENSATION");
  body(ctx, "You will be eligible to receive the following:", 0, 9.5);
  ctx.y += 2;
  body(ctx, `a. Annual pay (CTC) of    ${ctcAnnual} Per Annum.`, 4, 9.5);
  ctx.y += 2;
  body(ctx,
    "b. You are entitled to other compensation and benefits in accordance with the company policy as modified and inimated to you from time to time.",
    4, 9.5);
  ctx.y += 2;
  body(ctx, "c. Your salary will be reviewed periodically as per company policy.", 4, 9.5);
  ctx.y += 2;
  body(ctx,
    "d. Changes in your compensation are subject to the discretion of the company and will be subject to and be on the basis of your effective performance and results during your employment and other relevant criteria.",
    4, 9.5);
  ctx.y += 2;

  // ══════════════════════════════════════════════════════════════════
  // 3. OTHER BENEFITS
  // ══════════════════════════════════════════════════════════════════
  secHead(ctx, "3.OTHER BENEFITS");
  body(ctx, "You will be entitle to the following:", 0, 9.5);
  ctx.y += 2;
  body(ctx,
    "a.Leave,holidays and working hours as applicable to your category of employees and location of posting.",
    0, 9.5);
  ctx.y += 2;

  // ══════════════════════════════════════════════════════════════════
  // PAGE 2
  // ══════════════════════════════════════════════════════════════════
  addPage(ctx);

  // ── 4. RESPONSIBILITIES ───────────────────────────────────────────────────
  secHead(ctx, "4.RESPONSIBILITIES");
  body(ctx,
    "a. In view of your position and office, you must effectively,diligently and to the best of your ability perform all responsibilities and ensure results. There may be times when you will be expected to work extra hours to achieve the above when the job so requires. In this connection, you are required not to engage in activities that have or will have an adverse impact on the reputation/image and business of company whether directly or indirectly.",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "b. You will be required to under take travel on Company work for which you will be reimbused for travel expenses as per the company policy applicable to you.",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "c. We at MosIC solutions are committed to ensure 'Integrity' in all aspects of its functioning. You are expected to comply with the policies of the company including the Code of Business Conductand other policies of the company as they form an integral part of the terms of employment with MosIC solutions. Consequently you are required to understand the scope and intent behind these policies and to comply with the same. These policies are updated/modified on a periodic basis and new policies may be introduced and notified to employees from time to time and you will be required to comply with same.",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "d. Consistent with [c] above, any matter or situation or incident that may arise that could potentially result or has resulted, in any violation of the policies or the terms of your employment, shall immediately be brought to the notice of your Business unit head or manager.",
    0, 9.5);
  ctx.y += 4;

  // ── 5. CONFLICTS OF INTEREST ──────────────────────────────────────────────
  secHead(ctx, "5. CONFLICTS OF INTEREST");
  body(ctx,
    "a. You are required to engage yourself exclusively in the work assigned by MosIC solutions and shall not take up any independent or individual assignments (whether the same is part time or full time, in an advisory capacity or otherwise) directly or indirectly without the express written consent of your Business Unit Head.",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "b. you shall ensure that you shall not,directly or indirectly, engage any activity or ave any interest in, or perform any services for any person who is involved in activities, which are or shall be in conflict with the interests of MosIC Solutions.",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "c. The Conflict of interest Policy also refers to the need on your part, during your employement and for a period of one year from the cessation of your employment with MosIC solutions ( irrespective of the circumstances of, or the reasons for the cessation) not to solicit, induce or encourage:",
    0, 9.5);
  ctx.y += 2;
  body(ctx,
    "i.Any employee of MosIC solutions to terminate their employment with MosIC solutions or to accept employment with any competitor, supplier or any customer with whom you have a connection.",
    6, 9.5);
  ctx.y += 2;
  body(ctx,
    "ii. Any customer or vendor of MosIC solutions to move his existing business with MosIC solutions to a third party or to terminate his business relationship with MosIC solutions.",
    6, 9.5);
  ctx.y += 2;
  body(ctx,
    "iii. Any existing employee to become associated with, or perform services of any type for any third party.",
    6, 9.5);
  ctx.y += 3;
  body(ctx,
    "d. In case of any conflict or doubt,please discuss the matter with your Business Unit Head,to understand the position of MosIC solutions and resolve the conflict.",
    0, 9.5);

  // ══════════════════════════════════════════════════════════════════
  // PAGE 3
  // ══════════════════════════════════════════════════════════════════
  addPage(ctx);

  // ── 6. CONFIDENTIALITY ────────────────────────────────────────────────────
  secHead(ctx, "6. CONFIDENTIALITY");
  body(ctx,
    "a. In consideration of the opportunities, training and access to new techniques and know-how that will be made available to you, you will be required to comply with the confidentiality policy of the company. Therefore,please ensure that you as secret and confidential all Confidential Information ( as defined from time to time in the Confidentiality Policy of the company) and shall not use or disclose any such Confidential information except as may be required under obligation of law or as may be required by MosIC solutions and in the course of your employment. This covenant shall endure during your ( employment irrespective of the circumstances of, or the reasons, for the cessation).",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "b.In your work for MosIC solutions,you will be expected not to use or disclose any confidential information, including trade secrets, of any former employer or other person with whom you have and obligation of confidentiality and by signing below you affirm that you have you have no conflicting obligations or non-complete agreements that would prevent you from working without limitation for MosIC solutions.",
    0, 9.5);
  ctx.y += 4;

  // ── 7. ASSIGNMENT OF INTELLECTUAL PROPERTY ────────────────────────────────
  secHead(ctx, "7. ASSIGNMENT OF INTELLECTUAL PROPERTY");
  body(ctx,
    "During you tenure with the company you shall disclose and assign to MosIC solutions as its exclusive property, all developments developed or conceived by you solely or jointly with others that are related to the company's business or that results from work that you perform for the Company or using the Company's equipement, supplies or facilities and shall comply with policy.",
    0, 9.5);
  ctx.y += 4;

  // ── 8. NON-COMPETE ────────────────────────────────────────────────────────
  secHead(ctx, "8. NON-COMPETE");
  body(ctx,
    "In the course of your employment with the Company you will be providing services to customers or clients of the Company during which process you would be handling sensitive information including but not limited to key customers of the Company, competitor information, customer sensitive information ('Confidential Information').You acknowledge and recognize that confidential information available to you, if leaked would cause irreparable harm to the company and its protection is of utmost importance to ( the Company. You confirm that for a period of six (6) months after separation of your employment from the company irrespective of the circumstances of or the reason for the separation), you will not accept any offer of employment from a customer or client with whom you have interacted or worked in a professional capacity representing the Company client with whom you have interacted or worked in a professional capacity representing the Company during the six(6)month preceding the date of separation.",
    0, 9.5);
  ctx.y += 4;

  // ── 9. GENERAL ────────────────────────────────────────────────────────────
  secHead(ctx, "9. GENERAL");
  body(ctx,
    "a. We trust that you have not provided us with any false declaration or wilfully suppressed any material information. If you have, you will be liable to be removed from service without any prior notice.Please note that you are required to inform us if there are any agreements,oral or written, which you have entered into and which may relate to or affect your commitments under this agreement.",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "b. Your employment terms may be specifically enforce legally,if required. In this connection,if any of the provisions of the this Agreement are declared or found to be void or unenforceable due to any reason whatsoever,the remaining provisions of this Agreement shall continue in full force and effect.",
    0, 9.5);
  ctx.y += 3;
  body(ctx,
    "c. These employment terms supersede and replace any existing Agreement or understanding, if between MosIC solutions and you relating the same subject matter.",
    0, 9.5);

  // ══════════════════════════════════════════════════════════════════
  // PAGE 4
  // ══════════════════════════════════════════════════════════════════
  addPage(ctx);

  // ── 9. GENERAL (d) — continued ────────────────────────────────────────────
  body(ctx,
    "d. You warrant that you are not prevented by a court or by any other administrative or judicial order from providing the service required under this agreement. In the event that you are not a citizen of the country of posting, you should have a valid work permit to work in the country of posting.",
    0, 9.5);
  ctx.y += 4;

  // ── 10. NOTICE PERIOD ─────────────────────────────────────────────────────
  secHead(ctx, "10. NOTICE PERIOD");
  body(ctx,
    "This contract of employment is terminable, without resons, by either party giving two months prior written notice. MosIC solution reserves the right to pay or recover salary in lieu of notice period. Further, the company may be at its discretion relieve you from such date as it may deem fit even prior to the expiry of the notice period. However if the management desires the employee to continue the employment during the notice period, the employee shall do so.",
    0, 9.5);
  ctx.y += 4;
  body(ctx,
    "Please confirm that the above terms are acceptable to you and that you accept the appointment by signing copy of this letter of appointment.",
    0, 9.5);
  ctx.y += 6;

  // ── Closing ───────────────────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);
  doc.setTextColor(20, 20, 20);
  doc.text("Sincerely,",                 ml, ctx.y); ctx.y += 5;
  doc.text("for MosIC solution(p)Ltd",  ml, ctx.y); ctx.y += 22;
  doc.text("Managing Director",         ml, ctx.y); ctx.y += 16;

  // ── Declaration & Acknowledgment ─────────────────────────────────────────
  // Section heading (slightly larger, normal weight — matches PDF screenshot)
  doc.setFont("helvetica", "normal");
  doc.setFontSize(14);
  doc.setTextColor(20, 20, 20);
  doc.text("Declaration & Acknowledgment from Employee:", ml, ctx.y);
  ctx.y += 7;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);
  doc.text(" I have read, Understood and agree to accept employment on the terms and conditions herein.", ml, ctx.y);
  ctx.y += 7;
  doc.text("I shall be reporting to duty on", ml, ctx.y); ctx.y += 9;
  doc.text("Name :",      ml, ctx.y); ctx.y += 9;
  doc.text("Signature:",  ml, ctx.y); ctx.y += 9;
  doc.text("Date :",      ml, ctx.y); ctx.y += 9;
  doc.text("Place :",     ml, ctx.y);

  // ── Save ─────────────────────────────────────────────────────────────────
  doc.save(
    `${Date.now()}-APPOINTMENT_${emp.id}_${emp.empName}_${emp.empLastName}.pdf`,
  );
}