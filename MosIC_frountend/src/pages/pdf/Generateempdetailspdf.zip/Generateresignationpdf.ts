/**
 * generateResignationPDF.ts
 *
 * Generates a Relieving / Resignation Letter PDF.
 * Matches the exact layout of PDFDESIGN_RESIGNATION.java output.
 *
 * Layout (single page, A4):
 *   • Top-left  : Company logo placeholder box
 *   • Top-right : Company name (large) + address lines in two columns
 *   • Horizontal separator lines (thick)
 *   • "RESIGNATION LETTER" banner (centred, between lines)
 *   • DATE top-right
 *   • "TO WHOMSOEVER IT MAY CONCERN" large centred heading
 *   • Certification paragraph
 *   • Authorised signatory + Director (spaced below)
 *
 * Usage:
 *   import { generateResignationPDF } from "./pdf/generateResignationPDF";
 *   generateResignationPDF(row, emp, joiningDate, relievingDate);
 */

import jsPDF from "jspdf";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface EmpPositionDTO {
  id: number | null;
  empId: number | null;
  epDate: string;
  epEfficientDate: string;
  position: string;
  department: string;
  role: string;
  reportingTo: string;
  empBasic: string;
  empHra: string;
  empAllowance: string;
  empMonthGross: string;
  empCtc: string;
  empTds: string;
  empPt: string;
  empLoans: string;
  activeStatus: string;
  status: string;
}

export interface EmpDTO {
  id: number;
  empName: string;
  empLastName: string;
  empEmail?: string;
  empPhone?: string;
  empMail?: string;
  empPh?: string;
  empAddress1?: string;
  empAddress2?: string;
  empAddress3?: string;
  empDoj?: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const fmtDate = (d: string | undefined | null): string => {
  if (!d) return "";
  const parts = d.includes("-") ? d.split("-") : d.split("/");
  if (parts.length !== 3) return d;
  if (parts[0].length === 2) return d; // already DD-MM-YYYY
  const [y, m, day] = parts;
  return `${day}-${m}-${y}`;
};

const todayDMY = (): string => {
  const now = new Date();
  const dd  = String(now.getDate()).padStart(2, "0");
  const mm  = String(now.getMonth() + 1).padStart(2, "0");
  return `${dd}-${mm}-${now.getFullYear()}`;
};

// ─── Main export ──────────────────────────────────────────────────────────────

/**
 * @param row           EmpPositionDTO for the employee's current position
 * @param emp           EmpDTO with employee personal details
 * @param joiningDate   First effective date (ISO or DD-MM-YYYY)
 * @param relievingDate Last working date (ISO or DD-MM-YYYY); defaults to today
 */
export function generateResignationPDF(
  row: EmpPositionDTO,
  emp: EmpDTO,
  joiningDate: string,
  relievingDate?: string,
): void {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw  = doc.internal.pageSize.getWidth();   // 210
  const ph  = doc.internal.pageSize.getHeight();  // 297
  const ml  = 15;                                 // left margin

  const joining   = fmtDate(joiningDate) || fmtDate(emp.empDoj) || "";
  const relieving = fmtDate(relievingDate) || todayDMY();
  const printDate = todayDMY();
  const empName   = `${emp.empName} ${emp.empLastName}`;
  const dept      = row.department || row.position || "";

  // ── Logo box (top-left, like the Java drawImage) ──────────────────────────
  // In the Java code the logo is drawn at x=15, y=pageHeight-80 (i.e. ~top area)
  // We replicate the bounding box; users can swap for a real image via jsPDF addImage.
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.4);
  doc.rect(ml, 8, 38, 30);                          // logo placeholder
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7);
  doc.setTextColor(160, 160, 160);
  doc.text("LOGO", ml + 12, 25);

  // ── Company name + address (top-right) ────────────────────────────────────
  const cx = ml + 42;                               // text starts after logo gap
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(20, 20, 20);
  doc.text("MosIC Solutions Pvt Ltd", cx, 18);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(40, 40, 40);

  const right = pw - ml;
  doc.text("No 5 Second A Cross Rajashree Layout,Munnekolala,Marathahalli,", cx, 24);
  doc.text("Bangalore 560037", cx, 30);
  doc.text("Karnataka",                              right, 30, { align: "right" });
  doc.text("GST No: 29AAICM6836G1Z3",               cx,    36);
  doc.text("PAN No:AAICM6836G",                     right, 36, { align: "right" });
  doc.text("CIN No:U72200KA2013PTC069886",           cx,    42);
  doc.text("Website:www.mosics.com",                 right, 42, { align: "right" });
  doc.text("Phone: +91-9980914698",                  cx,    48);
  doc.text("Email: salesandsupport@mosics.com",      right, 48, { align: "right" });

  // ── Top horizontal rule ───────────────────────────────────────────────────
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(1.5);
  doc.line(ml, 56, pw - ml, 56);

  // ── "RESIGNATION LETTER" banner ───────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(14);
  doc.setTextColor(20, 20, 20);
  doc.text("RESIGNATION LETTER", pw / 2, 64, { align: "center" });

  // ── Bottom rule of banner ─────────────────────────────────────────────────
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(1.5);
  doc.line(ml, 68, pw - ml, 68);

  // ── DATE (top-right, below banner) ───────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(40, 40, 40);
  doc.text(`DATE :${printDate}`, right, 76, { align: "right" });

  // ── "TO WHOMSOEVER IT MAY CONCERN" heading ────────────────────────────────
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(20, 20, 20);
  doc.text("TO WHOMSOEVER IT MAY CONCERN", pw / 2, 96, { align: "center" });

  // ── Certification lines (matching the exact multi-column Java layout) ─────
  // Java does addSingleLineTextwal in separate x-positioned calls so the words
  // sit on the same baseline in distinct positions.  We replicate that here.
  doc.setFont("helvetica", "normal");
  doc.setFontSize(13);
  doc.setTextColor(20, 20, 20);

  //  "Hereby it is certified that   <name>   has been working as"
  const line1y = 112;
  doc.text("Hereby it is certified that", ml, line1y);
  doc.text(emp.empName,                    ml + 68, line1y);
  doc.text("has been working as",          pw - ml, line1y, { align: "right" });

  //  "<dept>   from   <joiningDate>   to   <relievingDate>"
  const line2y = 122;
  doc.text(dept,          ml,           line2y);
  doc.text("from",        ml + 55,      line2y);
  doc.text(joining,       ml + 75,      line2y);
  doc.text("to",          ml + 110,     line2y);
  doc.text(relieving,     pw - ml,      line2y, { align: "right" });

  // ── Performance sentence ──────────────────────────────────────────────────
  doc.setFontSize(13);
  const perf1 = "During this period, his/her performance is very good and we wish him/her";
  const perf2 = "success for all future endeavours.";
  doc.text(perf1, ml, 136);
  doc.text(perf2, ml, 148);

  // ── Authorised signatory ──────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(13);
  doc.setTextColor(20, 20, 20);
  doc.text("Authorised signatory", ml + 12, 185);

  // ── Director ─────────────────────────────────────────────────────────────
  doc.text("Director", ml + 12, 230);

  // ── Save ─────────────────────────────────────────────────────────────────
  doc.save(
    `${Date.now()}-RESIGNATION_${emp.id}_${emp.empName}_${emp.empLastName}.pdf`,
  );
}