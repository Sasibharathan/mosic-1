/**
 * generateEmpPositionPDF.ts
 *
 * Generates employee HR letters as professional PDFs using jsPDF.
 * Mirrors the style and structure of generateSalesPDF.ts.
 *
 * Three document types (matching PDFDESIGN_*.java originals):
 *   1. Appointment / Offer Letter   → generateAppointmentPDF(row, emp)
 *   2. Pay Hike Letter              → generatePayHikePDF(row, emp)
 *   3. Relieving / Resignation      → generateRelievingPDF(row, emp, joiningDate, relievingDate)
 *
 * All functions accept data directly from EmpPositionPage state
 * (EmpPositionDTO + EmpDTO) so NO extra API calls are required —
 * EmpPositionPage already has everything it needs.
 *
 * Usage from EmpPositionPage (src/pages/pdf/):
 *   import {
 *     generateAppointmentPDF,
 *     generatePayHikePDF,
 *     generateRelievingPDF,
 *   } from "./generateEmpPositionPDF";
 *
 *   // inside LetterBar:
 *   generateAppointmentPDF(row, emp);
 *   generatePayHikePDF(row, emp);
 *   generateRelievingPDF(row, emp, joiningDate, relievingDate);
 */

import jsPDF from "jspdf";

// ─── Shared types (copy of what EmpPositionPage already declares) ─────────────

export interface EmpPositionDTO {
  id: number | null;
  empId: number | null;
  epDate: string;
  epEfficientDate: string;
  position: string;
  department: string;
  role: string;
  reportingTo: string;
  empBasic: string;
  empHra: string;
  empAllowance: string;
  empMonthGross: string;
  empCtc: string;
  empTds: string;
  empPt: string;
  empLoans: string;
  activeStatus: string;
  status: string;
}

export interface EmpDTO {
  id: number;
  empName: string;
  empLastName: string;
  empEmail?: string;
  empPhone?: string;
  empMail?: string;
  empPh?: string;
  empAddress1?: string;
  empAddress2?: string;
  empAddress3?: string;
  empDoj?: string;
}

// ─── Company constants (same as generateSalesPDF) ────────────────────────────

const COMPANY = {
  name:    "MosIC Solutions Pvt Ltd",
  addr1:   "No 5 Second A Cross Rajashree Layout, Munnekolala, Marathahalli,",
  addr2:   "Bangalore 560037, Karnataka.",
  gst:     "GST No: 29AAICM6836G1Z3",
  pan:     "PAN No: AAICM6836G",
  cin:     "CIN No: U72200KA2013PTC069886",
  website: "Website: www.mosics.com",
  phone:   "Phone: +91-9980914698",
  email:   "Email: salesandsupport@mosics.com",
};

// Brand colours matching the Java originals
const BLUE:  [number, number, number] = [30,  80,  162];
const BLACK: [number, number, number] = [20,  20,   20];
const GREY:  [number, number, number] = [90,  90,   90];
const LIGHT: [number, number, number] = [245, 247, 252];

// ─── Helpers ─────────────────────────────────────────────────────────────────

const fmt = (v: unknown): string =>
  v != null && String(v).trim() ? String(v).trim() : "";

const num = (v: unknown): number => parseFloat(String(v ?? 0)) || 0;
const cur = (v: unknown): string => num(v).toFixed(2);

/** DD-MM-YYYY from YYYY-MM-DD or as-is if already formatted */
const fmtDate = (d: string | undefined | null): string => {
  if (!d) return "";
  const parts = d.includes("-") ? d.split("-") : d.split("/");
  if (parts.length !== 3) return d;
  if (parts[0].length === 2) return d;           // already DD-MM-YYYY
  const [y, m, day] = parts;
  return `${day}-${m}-${y}`;
};

const todayDMY = (): string => {
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, "0");
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  return `${dd}-${mm}-${now.getFullYear()}`;
};

// ─── Shared PDF builder utilities ─────────────────────────────────────────────

interface PdfCtx {
  doc:   jsPDF;
  pw:    number;
  ph:    number;
  ml:    number;   // left margin
  mr:    number;   // right margin
  cw:    number;   // content width
  y:     number;
  pageNum: number;
}

function newDoc(): PdfCtx {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw  = doc.internal.pageSize.getWidth();
  const ph  = doc.internal.pageSize.getHeight();
  const ml  = 15;
  const mr  = 15;
  return { doc, pw, ph, ml, mr, cw: pw - ml - mr, y: 0, pageNum: 1 };
}

/** Draw company letterhead identical to Java originals */
function drawHeader(ctx: PdfCtx): void {
  const { doc, pw, ml, cw } = ctx;

  // Company name — large
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(...BLACK);
  doc.text(COMPANY.name, ml, 18);

  // Address lines — two columns (left and right) like the Java code
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...GREY);

  const right = pw - ml;
  doc.text(COMPANY.addr1,   ml, 24);
  doc.text(COMPANY.addr2,   ml, 29);
  doc.text(COMPANY.gst,     ml, 34);   doc.text(COMPANY.pan,     right, 34, { align: "right" });
  doc.text(COMPANY.cin,     ml, 39);   doc.text(COMPANY.website, right, 39, { align: "right" });
  doc.text(COMPANY.phone,   ml, 44);   doc.text(COMPANY.email,   right, 44, { align: "right" });

  // Top separator line
  doc.setDrawColor(...BLUE);
  doc.setLineWidth(0.8);
  doc.line(ml, 48, ml + cw, 48);

  ctx.y = 52;
}

/** Draw a centred banner title (between two lines) like the Java originals */
function drawBanner(ctx: PdfCtx, title: string): void {
  const { doc, pw, ml, cw } = ctx;

  doc.setFillColor(...BLUE);
  doc.rect(ml, ctx.y, cw, 10, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(255, 255, 255);
  doc.text(title, pw / 2, ctx.y + 7, { align: "center" });

  ctx.y += 12;
}

/** Draw footer page number */
function drawFooter(ctx: PdfCtx): void {
  const { doc, pw, ph, ml, mr } = ctx;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(160, 160, 160);
  doc.text(
    `Page ${ctx.pageNum}  |  ${COMPANY.name}  |  ${COMPANY.email}`,
    pw / 2, ph - 8, { align: "center" }
  );
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  doc.line(ml, ph - 12, pw - mr, ph - 12);
}

/** Ensure space; add new page if needed */
function ensureSpace(ctx: PdfCtx, needed: number): void {
  if (ctx.y + needed > ctx.ph - 20) {
    drawFooter(ctx);
    ctx.doc.addPage();
    ctx.pageNum += 1;
    ctx.y = 18;
  }
}

/** Section heading (bold small-caps style) */
function sectionHead(ctx: PdfCtx, text: string): void {
  const { doc, ml, cw } = ctx;
  ensureSpace(ctx, 12);
  doc.setFillColor(...LIGHT);
  doc.rect(ml, ctx.y, cw, 7, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...BLUE);
  doc.text(text, ml + 2, ctx.y + 5);
  ctx.y += 9;
}

/** Plain body text, left-aligned */
function bodyText(ctx: PdfCtx, text: string, indent = 0, color: [number, number, number] = BLACK): void {
  const { doc, ml, cw } = ctx;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(...color);
  const lines = doc.splitTextToSize(text, cw - indent);
  ensureSpace(ctx, lines.length * 5 + 2);
  doc.text(lines, ml + indent, ctx.y);
  ctx.y += lines.length * 5 + 1;
}

/** Key : Value in two columns */
function kv(ctx: PdfCtx, label: string, value: string, x?: number, y?: number): void {
  const { doc, ml } = ctx;
  const lx = x ?? ml;
  const ly = y ?? ctx.y;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(...GREY);
  doc.text(label, lx, ly);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...BLACK);
  doc.text(value, lx + 32, ly);
}

// ─── 1. APPOINTMENT / OFFER LETTER ───────────────────────────────────────────

/**
 * Generates an Appointment (Offer) Letter PDF.
 * Mirrors PDFDESIGN_APPOINTMENT.java output.
 */
export function generateAppointmentPDF(
  row: EmpPositionDTO,
  emp: EmpDTO,
  letterDate?: string,        // ISO yyyy-mm-dd; defaults to today
): void {
  const ctx  = newDoc();
  const { doc, pw, ml, cw } = ctx;

  const date      = fmtDate(letterDate) || todayDMY();
  const effDate   = fmtDate(row.epEfficientDate || row.epDate) || date;
  const refNo     = `APP/LTR/${effDate}/${row.empId ?? emp.id}`;
  const empName   = `${emp.empName} ${emp.empLastName}`;
  const addr      = [emp.empAddress1, emp.empAddress2, emp.empAddress3].filter(Boolean);
  const ctcAnnual = cur(row.empCtc);

  // ── Header ──
  drawHeader(ctx);
  drawBanner(ctx, "LETTER OF APPOINTMENT");

  // ── Ref + Date row ──
  ensureSpace(ctx, 12);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(8.5);
  doc.setTextColor(...GREY);
  doc.text(`Ref No: ${refNo}`, ml, ctx.y);
  doc.text(`Date : ${date}`, pw - ml, ctx.y, { align: "right" });
  ctx.y += 7;

  // ── "To" address block ──
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(...BLACK);
  doc.text("To", ml, ctx.y);
  ctx.y += 5;
  doc.text(`${empName},`, ml, ctx.y); ctx.y += 5;
  addr.forEach((line) => { doc.text(`${line}`, ml, ctx.y); ctx.y += 5; });
  ctx.y += 4;

  // ── Salutation ──
  bodyText(ctx, `Dear ${empName},`);
  ctx.y += 2;
  bodyText(
    ctx,
    `It is our pleasure in appointing you in MosIC Solutions (P) Ltd., as ${fmt(row.position)} in ${fmt(row.department)} or in such other capacity the management shall from time to time determine. Please note that the employment terms contained in this letter are subject to the company policy.`,
  );
  ctx.y += 4;

  // ── 1. APPOINTMENT ──
  sectionHead(ctx, "1.  APPOINTMENT");
  bodyText(ctx, `1.  Your date of appointment is effective from ${effDate}.`, 4);
  bodyText(
    ctx,
    "2.  You will be liable to be transferred in such capacity as the company may from time to time determine to any other location, department, function, establishment, or branch of the company or its subsidiary, associate or affiliate Company. In such case you will be governed by the terms and conditions of service applicable to the new assignment.",
    4,
  );
  bodyText(ctx, "3.  The age of retirement is 58 Years.", 4);
  ctx.y += 3;

  // ── 2. COMPENSATION ──
  sectionHead(ctx, "2.  COMPENSATION");
  bodyText(ctx, "You will be eligible to receive the following:", 0);
  ctx.y += 2;

  // Salary table
  ensureSpace(ctx, 40);
  const tl = ml + 6, tr = ml + cw - 6;
  const rows2: [string, string][] = [
    ["Basic Pay",          cur(row.empBasic)],
    ["HRA",                cur(row.empHra)],
    ["Other Allowance",    cur(row.empAllowance)],
    ["Monthly Gross",      cur(row.empMonthGross)],
    ["Annual CTC",         `${ctcAnnual} Per Annum`],
  ];

  // Table header
  doc.setFillColor(...BLUE);
  doc.rect(ml, ctx.y, cw, 7, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text("Component", tl, ctx.y + 5);
  doc.text("Amount (₹)", tr, ctx.y + 5, { align: "right" });
  ctx.y += 7;

  rows2.forEach(([label, val], i) => {
    const rowH = 7;
    if (i % 2 === 0) { doc.setFillColor(...LIGHT); doc.rect(ml, ctx.y, cw, rowH, "F"); }
    doc.setDrawColor(220, 220, 220);
    doc.setLineWidth(0.2);
    doc.rect(ml, ctx.y, cw, rowH);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(...BLACK);
    doc.text(label, tl, ctx.y + 5);
    const isBold = label === "Annual CTC" || label === "Monthly Gross";
    doc.setFont("helvetica", isBold ? "bold" : "normal");
    doc.setTextColor(...(isBold ? BLUE : BLACK));
    doc.text(val, tr, ctx.y + 5, { align: "right" });
    ctx.y += rowH;
  });
  ctx.y += 5;

  bodyText(ctx, "b.  You are entitled to other compensation and benefits in accordance with the company policy as modified and intimated to you from time to time.", 4);
  bodyText(ctx, "c.  Your salary will be reviewed periodically as per company policy.", 4);
  bodyText(ctx, "d.  Changes in your compensation are subject to the discretion of the company and will be based on your effective performance and results during your employment.", 4);
  ctx.y += 3;

  // ── 3. OTHER BENEFITS ──
  sectionHead(ctx, "3.  OTHER BENEFITS");
  bodyText(ctx, "a.  Leave, holidays and working hours as applicable to your category of employees and location of posting.", 4);
  ctx.y += 3;

  // ── 4. RESPONSIBILITIES ──
  sectionHead(ctx, "4.  RESPONSIBILITIES");
  bodyText(ctx, "a.  In view of your position and office, you must effectively, diligently and to the best of your ability perform all responsibilities and ensure results. There may be times when you will be expected to work extra hours to achieve the above when the job so requires.", 4);
  bodyText(ctx, "b.  You will be required to undertake travel on Company work for which you will be reimbursed for travel expenses as per the company policy applicable to you.", 4);
  bodyText(ctx, "c.  We at MosIC Solutions are committed to ensure 'Integrity' in all aspects of its functioning. You are expected to comply with the policies of the company including the Code of Business Conduct.", 4);
  ctx.y += 3;

  // ── 5. CONFLICTS OF INTEREST ──
  sectionHead(ctx, "5.  CONFLICTS OF INTEREST");
  bodyText(ctx, "a.  You are required to engage yourself exclusively in the work assigned by MosIC Solutions and shall not take up any independent or individual assignments directly or indirectly without the express written consent of your Business Unit Head.", 4);
  bodyText(ctx, "b.  You shall ensure that you do not, directly or indirectly, engage in any activity or have any interest that is in conflict with the interests of MosIC Solutions.", 4);
  ctx.y += 3;

  // ── 6. CONFIDENTIALITY ──
  sectionHead(ctx, "6.  CONFIDENTIALITY");
  bodyText(ctx, "a.  You will be required to comply with the confidentiality policy of the company and shall not use or disclose any Confidential Information except as required under obligation of law or as required by MosIC Solutions in the course of your employment.", 4);
  ctx.y += 3;

  // ── 10. NOTICE PERIOD ──
  sectionHead(ctx, "10.  NOTICE PERIOD");
  bodyText(ctx, "This contract of employment is terminable, without reasons, by either party giving two months prior written notice. MosIC Solutions reserves the right to pay or recover salary in lieu of the notice period.", 0);
  ctx.y += 5;

  // ── Closing ──
  ensureSpace(ctx, 14);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(...BLACK);
  doc.text("Please confirm that the above terms are acceptable to you and that you accept the appointment by signing a copy of this letter.", ml, ctx.y, { maxWidth: cw });
  ctx.y += 8;
  doc.text("Sincerely,",           ml, ctx.y); ctx.y += 5;
  doc.text("for MosIC Solutions (P) Ltd",ml, ctx.y); ctx.y += 20;
  doc.setFont("helvetica", "bold");
  doc.text("Managing Director",    ml, ctx.y); ctx.y += 12;

  // ── Declaration ──
  ensureSpace(ctx, 42);
  doc.setFillColor(...LIGHT);
  doc.rect(ml, ctx.y, cw, 40, "F");
  doc.setDrawColor(...BLUE);
  doc.setLineWidth(0.4);
  doc.rect(ml, ctx.y, cw, 40);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9.5);
  doc.setTextColor(...BLUE);
  doc.text("Declaration & Acknowledgment from Employee:", ml + 3, ctx.y + 7);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(...BLACK);
  doc.text("I have read, understood and agree to accept employment on the terms and conditions herein.", ml + 3, ctx.y + 14);
  doc.text("I shall be reporting to duty on :", ml + 3, ctx.y + 21);
  doc.text("Name       :",  ml + 3, ctx.y + 28);
  doc.text("Signature  :",  ml + 60, ctx.y + 28);
  doc.text("Date       :",  ml + 3, ctx.y + 35);
  doc.text("Place      :",  ml + 60, ctx.y + 35);
  ctx.y += 44;

  drawFooter(ctx);
  doc.save(`APPOINTMENT_${emp.id}_${emp.empName}_${emp.empLastName}.pdf`);
}

// ─── 2. PAY HIKE LETTER ───────────────────────────────────────────────────────

/**
 * Generates a Pay Hike Letter PDF.
 * Mirrors PDFDESIGN_HIKELETTER.java output.
 */
export function generatePayHikePDF(
  row: EmpPositionDTO,
  emp: EmpDTO,
  payMonth?: string,           // e.g. "3"  (1-12)
  payYear?: string,            // e.g. "2025"
  letterDate?: string,         // ISO yyyy-mm-dd
): void {
  const ctx  = newDoc();
  const { doc, pw, ml, cw } = ctx;

  const date    = fmtDate(letterDate) || todayDMY();
  const effDate = fmtDate(row.epEfficientDate || row.epDate) || date;
  const refNo   = `PYHK/LTR/${effDate}/${row.empId ?? emp.id}`;
  const empName = `${emp.empName} ${emp.empLastName}`;
  const addr    = [emp.empAddress1, emp.empAddress2, emp.empAddress3].filter(Boolean);

  const basic     = cur(row.empBasic);
  const hra       = cur(row.empHra);
  const allowance = cur(row.empAllowance);
  const gross     = cur(row.empMonthGross);

  const tds   = num(row.empTds);
  const pt    = num(row.empPt);
  const loans = num(row.empLoans);
  const totalDeduction = tds + pt + loans;
  const netSalary = num(row.empMonthGross) - totalDeduction;

  // Month label
  const monthNames = ["","JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE",
    "JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"];
  const monthLabel = payMonth
    ? `${monthNames[parseInt(payMonth, 10)] ?? payMonth}-${payYear ?? ""}`
    : "";

  // ── Header ──
  drawHeader(ctx);
  drawBanner(ctx, `PAY HIKE LETTER${monthLabel ? "  —  " + monthLabel : ""}`);

  // ── Ref + To + Date box ──
  ensureSpace(ctx, 52);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(...BLACK);
  doc.text(`REF NO: ${refNo}`, ml, ctx.y); ctx.y += 6;

  // Left: "TO" address
  const addrStartY = ctx.y;
  doc.setFont("helvetica", "bold"); doc.text("TO", ml, ctx.y); ctx.y += 5;
  doc.setFont("helvetica", "normal");
  doc.text(`${empName},`, ml, ctx.y); ctx.y += 5;
  addr.forEach((line) => { doc.text(`${line}`, ml, ctx.y); ctx.y += 5; });

  // Right: meta fields (fixed at addrStartY, right-aligned two-col)
  const rx1 = pw - ml - 60, rx2 = pw - ml;
  const metaRows: [string, string][] = [
    ["DATE :",        date],
    ["DESIGNATION :", fmt(row.position)],
    ["EMAIL :",       fmt(emp.empMail ?? emp.empEmail)],
    ["CURRENCY :",    "INR"],
  ];
  metaRows.forEach(([label, val], i) => {
    const ry = addrStartY + i * 6;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(...GREY);
    doc.text(label, rx1, ry);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...BLACK);
    doc.text(val, rx2, ry, { align: "right" });
  });

  ctx.y += 6;

  // ── Body paragraph ──
  bodyText(ctx, `DEAR ${emp.empName},`);
  ctx.y += 2;
  bodyText(
    ctx,
    `We are pleased to communicate to you that based on the Performance appraisal your salary is revised and the new monthly salary is as follows:`,
  );
  ctx.y += 4;

  // ── Payment table ──
  ensureSpace(ctx, 60);
  const tl = ml + 6, tr = ml + cw - 6;

  // Section label above table
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...BLACK);
  doc.text("Payment", ml, ctx.y); ctx.y += 4;

  // Table header
  doc.setFillColor(...BLUE);
  doc.rect(ml, ctx.y, cw, 7, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text("Component", tl, ctx.y + 5);
  doc.text("Amount (₹)", tr, ctx.y + 5, { align: "right" });
  ctx.y += 7;

  const salaryRows: [string, string, boolean][] = [
    ["FIXED PAY",       basic,     false],
    ["HRA",             hra,       false],
    ["OTHER ALLOWANCE", allowance, false],
    ["Gross Monthly Salary", gross, true],
  ];

  salaryRows.forEach(([label, val, isBold], i) => {
    const rowH = 7;
    if (i % 2 === 0) { doc.setFillColor(...LIGHT); doc.rect(ml, ctx.y, cw, rowH, "F"); }
    doc.setDrawColor(220, 220, 220);
    doc.setLineWidth(0.2);
    doc.rect(ml, ctx.y, cw, rowH);
    doc.setFont("helvetica", isBold ? "bold" : "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(...(isBold ? BLACK : BLUE));
    doc.text(label, tl, ctx.y + 5);
    doc.setFont("helvetica", isBold ? "bold" : "normal");
    doc.setTextColor(...(isBold ? BLACK : BLUE));
    doc.text(val, tr, ctx.y + 5, { align: "right" });
    ctx.y += rowH;
  });

  // Net salary row (highlighted)
  const netRowH = 8;
  doc.setFillColor(30, 80, 162);
  doc.rect(ml, ctx.y, cw, netRowH, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text("Net Salary (after deductions)", tl, ctx.y + 5.5);
  doc.text(cur(netSalary), tr, ctx.y + 5.5, { align: "right" });
  ctx.y += netRowH + 6;

  // ── Closing note ──
  bodyText(
    ctx,
    `New salary will be implemented from ${effDate} till further communication on salary revision.`,
  );
  ctx.y += 8;
  bodyText(ctx, "With Regards,");
  ctx.y += 3;
  bodyText(ctx, `(Authorised Signatory)`);
  ctx.y += 18;

  // Signature line
  ensureSpace(ctx, 20);
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.line(ml, ctx.y, ml + 60, ctx.y);
  ctx.y += 4;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...GREY);
  doc.text("Authorised Signatory", ml, ctx.y);

  drawFooter(ctx);
  doc.save(`HIKELETTER_${emp.id}_${emp.empName}_${emp.empLastName}.pdf`);
}

// ─── 3. RELIEVING / RESIGNATION LETTER ────────────────────────────────────────

/**
 * Generates a Relieving / Resignation Letter PDF.
 * Mirrors PDFDESIGN_RESIGNATION.java output.
 *
 * @param joiningDate  The employee's first effective date (DD-MM-YYYY or ISO)
 * @param relievingDate The last working date (DD-MM-YYYY or ISO); defaults to today
 */
export function generateRelievingPDF(
  row: EmpPositionDTO,
  emp: EmpDTO,
  joiningDate: string,
  relievingDate?: string,
): void {
  const ctx  = newDoc();
  const { doc, pw, ml, cw } = ctx;

  const joining   = fmtDate(joiningDate) || fmtDate(emp.empDoj) || "";
  const relieving = fmtDate(relievingDate) || todayDMY();
  const printDate = todayDMY();
  const empName   = `${emp.empName} ${emp.empLastName}`;

  // ── Header ──
  drawHeader(ctx);
  drawBanner(ctx, "RELIEVING / EXPERIENCE LETTER");

  // ── Date (top right) ──
  ensureSpace(ctx, 10);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...GREY);
  doc.text(`DATE : ${printDate}`, pw - ml, ctx.y, { align: "right" });
  ctx.y += 10;

  // ── "To Whomsoever" heading ──
  ensureSpace(ctx, 16);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(...BLUE);
  doc.text("TO WHOMSOEVER IT MAY CONCERN", pw / 2, ctx.y, { align: "center" });
  ctx.y += 14;

  // Decorative rule
  doc.setDrawColor(...BLUE);
  doc.setLineWidth(0.6);
  doc.line(ml, ctx.y, ml + cw, ctx.y);
  ctx.y += 6;

  // ── Certification paragraph ──
  ensureSpace(ctx, 28);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(...BLACK);

  const line1 = `Hereby it is certified that ${empName} has been working as`;
  const line2 = `${fmt(row.position) || fmt(row.department)} from ${joining} to ${relieving}.`;

  doc.text(line1, ml, ctx.y); ctx.y += 8;
  doc.text(line2, ml, ctx.y); ctx.y += 12;

  bodyText(
    ctx,
    "During this period, his/her performance is very good and we wish him/her success for all future endeavours.",
  );
  ctx.y += 24;

  // ── Signature block ──
  ensureSpace(ctx, 32);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...BLACK);
  doc.text("Authorised Signatory", ml, ctx.y); ctx.y += 26;

  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.4);
  doc.line(ml, ctx.y - 22, ml + 60, ctx.y - 22);

  doc.setFont("helvetica", "bold");
  doc.text("Director", ml, ctx.y); ctx.y += 26;
  doc.line(ml, ctx.y - 22, ml + 60, ctx.y - 22);

  drawFooter(ctx);
  doc.save(`RESIGNATION_${emp.id}_${emp.empName}_${emp.empLastName}.pdf`);
}