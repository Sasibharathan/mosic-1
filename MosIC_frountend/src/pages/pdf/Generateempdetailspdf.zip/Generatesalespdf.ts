/**
 * generateSalesPDF.ts
 *
 * Generates a Sales PDF for a single SALES_REGISTER record +
 * its SALES_DOCUMENT_ITEM_LIST line items.
 *
 * API endpoints:
 *   GET /api/sales/{id}                  → SalesDTO
 *   GET /api/sales-items/by-sales/{id}   → SalesItemDTO[]
 *   GET /api/customers/{id}              → CustomerDTO (ID parsed from party string)
 *
 * Party name format: "<customerId>-<name>", e.g. "44-xyz pvt ltd"
 * Logo: /images/logo/logo.jpg (served from public/)
 */

import jsPDF from "jspdf";
import axiosInstance from "../../utils/axiosInstance";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SalesRow {
  id:                  string | number;
  salesDate:           string;
  salesValidity?:      string;
  salesFromParty?:     string;
  salesToParty?:       string;
  salesEnquireDate?:   string;
  salesDeliveryTerms?: string;
  salesPaymentTerms?:  string;
  salesCurrency?:      string;
  salesDoctype?:       string | number;
  salesTxType?:        string;
  salesDescription?:   string;
  salesAddressedTo?:   string;
  salesFileRef?:       string;
  salesStatus?:        string | number;
}

export interface SalesItemRow {
  id?:                   string | number;
  nameOfProductService:  string;
  hsnAcs?:               string;
  quantity:              number | string;
  unit?:                 string;
  unitRate:              number | string;
  taxableValue:          number | string;
  cgstRate?:             number | string;
  cgstAmount?:           number | string;
  sgstRate?:             number | string;
  sgstAmount?:           number | string;
  igstRate?:             number | string;
  igstAmount?:           number | string;
  total:                 number | string;
  refFileNo?:            number | string;
}

export interface CustomerRow {
  id?:               string | number;
  name?:             string;
  gst?:              string;
  cin?:              string;
  pan?:              string;
  buyerAddress1?:    string;
  buyerAddress2?:    string;
  buyerAddress3?:    string;
  shippingAddress1?: string;
  shippingAddress2?: string;
  shippingAddress3?: string;
}

// ─── Company constants ────────────────────────────────────────────────────────

const COMPANY = {
  name:    "MosIC Solutions Pvt Ltd",
  address: "No 5 Second A Cross Rajashree Layout, Munnekolala, Marathahalli,",
  city:    "Bangalore 560037 Karnataka",
  gst:     "GST No: 29AAICM6836G1Z3",
  pan:     "PAN No: AAICM6836G",
  cin:     "CIN No: U72200KA2013PTC069886",
  website: "Website: www.mosics.com",
  phone:   "Phone: +91-9980914698",
  email:   "Email: salesandsupport@mosics.com",
};

const docTypeLabel = (v: string | number | undefined): string => {
  const map: Record<string, string> = {
    "1": "RFQ", "2": "QUOTATION", "3": "SUPPLY ORDER",
    "4": "INVOICE", "5": "PAYMENT", "6": "PAYMENT RECEIPT",
  };
  return map[String(v ?? "")] ?? "SALES DOCUMENT";
};

const fmt  = (v: unknown) => (v != null && String(v).trim() ? String(v).trim() : "—");
const num  = (v: unknown) => parseFloat(String(v ?? 0)) || 0;
const cur  = (v: unknown) => num(v).toFixed(2);

const toWords = (amount: number): string => {
  if (amount === 0) return "Zero Rupees";
  const ones = ["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine",
    "Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"];
  const tens = ["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"];
  const chunk = (n: number): string => {
    if (n === 0) return "";
    if (n < 20)  return ones[n] + " ";
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? " " + ones[n % 10] : "") + " ";
    return ones[Math.floor(n / 100)] + " Hundred " + chunk(n % 100);
  };
  const rounded = Math.round(amount);
  let result = "";
  if (rounded >= 10000000) result += chunk(Math.floor(rounded / 10000000)) + "Crore ";
  if (rounded >= 100000)   result += chunk(Math.floor((rounded % 10000000) / 100000)) + "Lakh ";
  if (rounded >= 1000)     result += chunk(Math.floor((rounded % 100000) / 1000)) + "Thousand ";
  result += chunk(rounded % 1000);
  return result.trim() + " Rupees Only";
};

const today = () =>
  new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });

const loadImage = (src: string): Promise<HTMLImageElement> =>
  new Promise((resolve, reject) => {
    const img = new Image();
    img.onload  = () => resolve(img);
    img.onerror = () => reject();
    img.src = src;
  });

// ─── Main export ──────────────────────────────────────────────────────────────

export async function generateSalesPDF(
  docId: string | number,
  prefetchedRow?: SalesRow,
  prefetchedItems?: SalesItemRow[],
  prefetchedCustomer?: CustomerRow,
): Promise<void> {

  let row:      SalesRow;
  let items:    SalesItemRow[];
  let customer: CustomerRow = {};

  if (prefetchedRow && prefetchedItems) {
    row      = prefetchedRow;
    items    = prefetchedItems;
    customer = prefetchedCustomer ?? {};
  } else {
    let rowRes, itemsRes;
    try {
      [rowRes, itemsRes] = await Promise.all([
        axiosInstance.get(`/api/sales/${docId}`),
        axiosInstance.get(`/api/sales-items/by-sales/${docId}`),
      ]);
    } catch (err: unknown) {
      const status = (err as { response?: { status?: number } })?.response?.status;
      if (status === 403) throw new Error(`Access denied fetching Sales record #${docId}. Check Spring Security roles for /api/sales.`);
      if (status === 401) throw new Error(`Session expired. Please log in again before generating the PDF.`);
      if (status === 404) throw new Error(`Sales record #${docId} was not found on the server.`);
      throw err;
    }
    row = rowRes.data as SalesRow;
    const rawItems = Array.isArray(itemsRes.data)
      ? itemsRes.data
      : (itemsRes.data?.items ?? itemsRes.data?.data ?? []);
    items = rawItems as SalesItemRow[];

    if (row.salesToParty) {
      try {
        const customerId = parseInt(String(row.salesToParty).split("-")[0], 10);
        if (!isNaN(customerId)) {
          const custRes = await axiosInstance.get(`/api/customers/${customerId}`);
          customer = custRes.data as CustomerRow;
        }
      } catch {
        // best-effort — PDF still generates without customer details
      }
    }
  }

  // ── Preload logo ───────────────────────────────────────────────────────────
  let logoImg: HTMLImageElement | null = null;
  try {
    logoImg = await loadImage("/images/logo/logo.jpg");
  } catch {
    // logo missing — will leave space blank
  }

  // ── Compute totals ─────────────────────────────────────────────────────────
  let totalTaxable = 0, totalCgst = 0, totalSgst = 0, totalIgst = 0, grandTotal = 0;
  items.forEach((it) => {
    totalTaxable += num(it.taxableValue);
    totalCgst    += num(it.cgstAmount);
    totalSgst    += num(it.sgstAmount);
    totalIgst    += num(it.igstAmount);
    grandTotal   += num(it.total);
  });
  const roundedTotal = Math.round(grandTotal);

  // ── PDF setup ──────────────────────────────────────────────────────────────
  const doc  = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw   = doc.internal.pageSize.getWidth();
  const ph   = doc.internal.pageSize.getHeight();
  const ml   = 14;
  const mr   = 14;
  const cw   = pw - ml - mr;
  let   y    = 0;
  let   pageNum = 1;

  // ── Header ─────────────────────────────────────────────────────────────────
  const drawHeader = () => {
    y = 10;

    // Logo
    if (logoImg) {
      doc.addImage(logoImg, "JPEG", ml, y, 22, 22);
    } else {
      doc.setDrawColor(180, 180, 180);
      doc.setLineWidth(0.4);
      doc.rect(ml, y, 22, 22);
      doc.setFont("helvetica", "italic");
      doc.setFontSize(7);
      doc.setTextColor(180, 180, 180);
      doc.text("LOGO", ml + 5, y + 12);
    }

    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(30, 30, 30);
    doc.text(COMPANY.name, ml + 26, y + 7);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(60, 60, 60);
    doc.text(COMPANY.address, ml + 26, y + 12);
    doc.text(COMPANY.city,    ml + 26, y + 16);

    const rx = pw - mr;
    doc.text(COMPANY.gst,     rx, y + 12, { align: "right" });
    doc.text(COMPANY.pan,     rx, y + 16, { align: "right" });
    doc.text(COMPANY.cin,     ml + 26, y + 20);
    doc.text(COMPANY.website, rx, y + 20, { align: "right" });
    doc.text(`${COMPANY.phone}   ${COMPANY.email}`, ml + 26, y + 24);

    doc.setDrawColor(180, 180, 180);
    doc.setLineWidth(0.4);
    doc.line(ml, y + 26, pw - mr, y + 26);
    y += 30;
  };

  // ── Footer ─────────────────────────────────────────────────────────────────
  const drawFooter = () => {
    const fy = ph - 10;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(140, 140, 140);
    doc.text(`Generated: ${today()}`, ml, fy);
    doc.text(`Page ${pageNum}`, pw / 2, fy, { align: "center" });
    doc.text("MosIC Solutions Pvt Ltd — Confidential", pw - mr, fy, { align: "right" });
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.3);
    doc.line(ml, fy - 3, pw - mr, fy - 3);
  };

  // ── Items table column header ───────────────────────────────────────────────
  const titleColor: [number, number, number] = [30, 80, 160];

  const cols = [
    { label: "S.NO",     w: 10 },
    { label: "NAME",     w: 42 },
    { label: "HSN&ACS",  w: 18 },
    { label: "QUANTITY", w: 16 },
    { label: "UNIT",     w: 12 },
    { label: "U RATE",   w: 16 },
    { label: "CGST",     w: 14 },
    { label: "SGST",     w: 14 },
    { label: "IGST",     w: 14 },
    { label: "TOTAL",    w: 16 },
  ];
  const usedW = cols.reduce((s, c) => s + c.w, 0);
  cols[cols.length - 1].w += cw - usedW;

  let tableHeaderDrawn = false;

  const drawItemsHeader = () => {
    doc.setFillColor(...titleColor);
    doc.rect(ml, y, cw, 8, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.setTextColor(255, 255, 255);
    let cx = ml;
    cols.forEach((col) => { doc.text(col.label, cx + 1.5, y + 5.5); cx += col.w; });
    y += 8;
  };

  // ── ensureSpace ────────────────────────────────────────────────────────────
  const ensureSpace = (needed: number) => {
    if (y + needed > ph - 18) {
      drawFooter();
      doc.addPage();
      pageNum++;
      drawHeader();
      if (tableHeaderDrawn) {
        drawItemsHeader();
      }
    }
  };

  // ═══════════════════════════════════════════════════════════════════════════
  drawHeader();

  // ── Title bar ──────────────────────────────────────────────────────────────
  doc.setFillColor(...titleColor);
  doc.rect(ml, y, cw, 9, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text(docTypeLabel(row.salesDoctype), pw / 2, y + 6.2, { align: "center" });
  y += 13;

  // ── Party + date block ─────────────────────────────────────────────────────
  const partyBoxH = 34;
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw * 0.55, partyBoxH);
  doc.rect(ml + cw * 0.55, y, cw * 0.45, partyBoxH);

  const lx = ml + 2;
  const partyFields: [string, string][] = [
    ["TO PARTY  :", fmt(row.salesToParty)],
    ["GST NO    :", fmt(customer.gst)],
    ["CIN NO    :", fmt(customer.cin)],
    ["PAN NO    :", fmt(customer.pan)],
  ];
  partyFields.forEach(([label, value], i) => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(80, 80, 80);
    doc.text(label, lx, y + 6 + i * 6);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(20, 20, 20);
    doc.text(value, lx + 24, y + 6 + i * 6);
  });

  const rx2 = ml + cw * 0.55 + 2;
  const rxv  = ml + cw - 2;
  const dateFields: [string, string][] = [
    ["DATE     :", fmt(row.salesDate)],
    ["VALIDITY :", fmt(row.salesValidity)],
    ["CURRENCY :", fmt(row.salesCurrency || "INR")],
  ];
  dateFields.forEach(([label, value], i) => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(80, 80, 80);
    doc.text(label, rx2, y + 6 + i * 6);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(20, 20, 20);
    doc.text(value, rxv, y + 6 + i * 6, { align: "right" });
  });
  y += partyBoxH + 2;

  // ── Billing / Shipping addresses ───────────────────────────────────────────
  const addrBoxH = 28;
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw / 2, addrBoxH);
  doc.rect(ml + cw / 2, y, cw / 2, addrBoxH);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(80, 80, 80);
  doc.text("BILLING ADDRESS :", ml + 2, y + 5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(20, 20, 20);
  doc.text(fmt(customer.buyerAddress1), ml + 4, y + 11);
  doc.text(fmt(customer.buyerAddress2), ml + 4, y + 16);
  doc.text(fmt(customer.buyerAddress3), ml + 4, y + 21);

  const sx = ml + cw / 2 + 2;
  doc.setFont("helvetica", "bold");
  doc.setTextColor(80, 80, 80);
  doc.text("SHIPPING ADDRESS :", sx, y + 5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(20, 20, 20);
  doc.text(fmt(customer.shippingAddress1), sx + 2, y + 11);
  doc.text(fmt(customer.shippingAddress2), sx + 2, y + 16);
  doc.text(fmt(customer.shippingAddress3), sx + 2, y + 21);
  y += addrBoxH;

  // ── Kind Attention ─────────────────────────────────────────────────────────
  if (row.salesAddressedTo) {
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.3);
    doc.rect(ml, y, cw, 8);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(80, 80, 80);
    doc.text("Kind Attention :", ml + 2, y + 5.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(20, 20, 20);
    doc.text(fmt(row.salesAddressedTo), ml + 36, y + 5.5);
    y += 8;
  }
  y += 4;

  // ── Line items table ────────────────────────────────────────────────────────
  drawItemsHeader();
  tableHeaderDrawn = true;

  if (items.length === 0) {
    doc.setFont("helvetica", "italic");
    doc.setFontSize(9);
    doc.setTextColor(140, 140, 140);
    doc.text("No line items found for this document.", ml + 3, y + 6);
    y += 10;
  } else {
    items.forEach((item, idx) => {
      const nameLines = doc.splitTextToSize(fmt(item.nameOfProductService), cols[1].w - 3);
      const rowH = Math.max(8, nameLines.length * 4.5 + 3);
      ensureSpace(rowH + 2);

      if (idx % 2 === 0) {
        doc.setFillColor(249, 250, 252);
        doc.rect(ml, y, cw, rowH, "F");
      }
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.2);
      doc.rect(ml, y, cw, rowH);

      let cx = ml;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(30, 30, 30);
      doc.text(String(idx + 1), cx + 1.5, y + 5); cx += cols[0].w;
      doc.setFont("helvetica", "normal");
      doc.text(nameLines, cx + 1.5, y + 5);        cx += cols[1].w;
      doc.text(fmt(item.hsnAcs), cx + 1.5, y + 5);     cx += cols[2].w;
      doc.text(fmt(item.quantity), cx + 1.5, y + 5);   cx += cols[3].w;
      doc.text(fmt(item.unit), cx + 1.5, y + 5);       cx += cols[4].w;
      doc.text(cur(item.unitRate), cx + 1.5, y + 5);   cx += cols[5].w;
      doc.text(cur(item.cgstAmount), cx + 1.5, y + 5); cx += cols[6].w;
      doc.text(cur(item.sgstAmount), cx + 1.5, y + 5); cx += cols[7].w;
      doc.text(cur(item.igstAmount), cx + 1.5, y + 5); cx += cols[8].w;
      doc.setFont("helvetica", "bold");
      doc.text(cur(item.total), cx + 1.5, y + 5);
      y += rowH;
    });
  }

  tableHeaderDrawn = false;
  y += 6;

  // ── Totals block ────────────────────────────────────────────────────────────
  ensureSpace(52);
  const totalsW = 76;
  const wordsW  = cw - totalsW - 2;

  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, wordsW, 36);
  doc.rect(ml + wordsW + 2, y, totalsW, 36);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(40, 40, 40);
  doc.text("TOTAL AMOUNT IN WORDS", ml + 2, y + 5.5);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  const wordLines = doc.splitTextToSize(toWords(roundedTotal).toLowerCase(), wordsW - 4);
  doc.text(wordLines, ml + 2, y + 11);

  const tx = ml + wordsW + 4;
  const tv = ml + wordsW + 2 + totalsW - 2;
  const totRows: [string, string][] = [
    ["TOTAL TAXABLE AMOUNT :", cur(totalTaxable)],
    ["TOTAL CGST :",           cur(totalCgst)],
    ["TOTAL SGST :",           cur(totalSgst)],
    ["TOTAL IGST :",           cur(totalIgst)],
    ["TOTAL :",                cur(grandTotal)],
    ["ROUND OFF :",            String(roundedTotal)],
  ];
  totRows.forEach(([label, value], i) => {
    const ty = y + 6 + i * 5.5;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(60, 60, 60);
    doc.text(label, tx, ty);
    doc.setTextColor(20, 20, 20);
    doc.text(value, tv, ty, { align: "right" });
  });
  y += 38;

  // ── Terms & Conditions ─────────────────────────────────────────────────────
  ensureSpace(30);
  const termsH = 28;
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw, termsH);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(40, 40, 40);
  doc.text("Terms and Conditions :", ml + 2, y + 5.5);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(60, 60, 60);
  if (row.salesPaymentTerms)  doc.text(`Payment Terms  : ${row.salesPaymentTerms}`,  ml + 2, y + 11);
  if (row.salesDeliveryTerms) doc.text(`Delivery Terms : ${row.salesDeliveryTerms}`, ml + 2, y + 16);
  if (row.salesDescription)   doc.text(`Description    : ${row.salesDescription}`,   ml + 2, y + 21);
  y += termsH + 4;

  // ── Signature ──────────────────────────────────────────────────────────────
  ensureSpace(26);
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw, 22);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(40, 40, 40);
  doc.text("FOR MOSIC SOLUTIONS PVT LTD", ml + 4, y + 6);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text("AUTHORISED SIGNATURE", ml + 4, y + 18);
  y += 26;

  drawFooter();

  const typeLabel = docTypeLabel(row.salesDoctype).replace(/\s+/g, "_");
  const filename  = `${typeLabel}_${row.id}_${(row.salesToParty || "party").replace(/[^a-zA-Z0-9]/g, "_").slice(0, 20)}.pdf`;
  doc.save(filename);
}