/**
 * generateFileIndexPDF.ts
 *
 * Generates a PDF for a single File Index record + all its activities.
 * Uses jsPDF directly (no html2canvas) for clean, fast, text-based output.
 *
 * Install once:
 *   npm install jspdf
 */

import jsPDF from "jspdf";
import type { FileIndexRow, ActivityRow } from "../FileIndex/FileIndex.shared";

// ─── Company constants ────────────────────────────────────────────────────────

const COMPANY = {
  name:    "MosIC Solutions Pvt Ltd",
  address: "No 5 Second A Cross Rajashree Layout, Munnekolala, Marathahalli,",
  city:    "Bangalore 560037 Karnataka",
  gst:     "GST No: 29AAICM6836G1Z3",
  pan:     "PAN No: AAICM6836G",
  cin:     "CIN No: U72200KA2013PTC069886",
  website: "Website: www.mosics.com",
  phone:   "Phone: +91-9980914698",
  email:   "Email: salesandsupport@mosics.com",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmt = (v: string | undefined | null) => (v && v.trim() ? v.trim() : "—");

const statusLabel = (v: string) => {
  if (v === "1" || v === "ACTIVE")    return "Active";
  if (v === "0" || v === "INACTIVE" || v === "DISABLED") return "Inactive";
  if (v === "PENDING")    return "Pending";
  if (v === "COMPLETED")  return "Completed";
  return v || "—";
};

const today = () =>
  new Date().toLocaleDateString("en-IN", {
    day: "2-digit", month: "short", year: "numeric",
  });

// ─── Main export ──────────────────────────────────────────────────────────────

export function generateFileIndexPDF(
  file: FileIndexRow,
  activities: ActivityRow[],
): void {
  const doc  = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw   = doc.internal.pageSize.getWidth();   // 210
  const ph   = doc.internal.pageSize.getHeight();  // 297
  const ml   = 14;   // left margin
  const mr   = 14;   // right margin
  const cw   = pw - ml - mr;  // content width
  let   y    = 0;

  let pageNum = 1;

  // ── Draw header (repeated on every page) ──────────────────────────────────
  const drawHeader = () => {
    y = 10;

    // Outer border rect
    doc.setDrawColor(180, 180, 180);
    doc.setLineWidth(0.4);
    doc.rect(ml, y, cw, 28);

    // Company name
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(30, 30, 30);
    doc.text(COMPANY.name, ml + 4, y + 7);

    // Address lines
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(60, 60, 60);
    doc.text(COMPANY.address, ml + 4, y + 12);
    doc.text(COMPANY.city,    ml + 4, y + 16);
    doc.text(COMPANY.gst,     ml + 4, y + 20);
    doc.text(COMPANY.cin,     ml + 4, y + 24);

    // Right column
    const rx = pw - mr - 4;
    doc.setFont("helvetica", "normal");
    doc.text(COMPANY.pan,     rx, y + 20, { align: "right" });
    doc.text(COMPANY.website, rx, y + 24, { align: "right" });

    // Phone / email row
    doc.text(`${COMPANY.phone}   ${COMPANY.email}`, ml + 4, y + 28.5);

    y += 32;
  };

  // ── Draw footer ────────────────────────────────────────────────────────────
  const drawFooter = () => {
    const fy = ph - 10;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(140, 140, 140);
    doc.text(`Generated: ${today()}`, ml, fy);
    doc.text(`Page ${pageNum}`, pw / 2, fy, { align: "center" });
    doc.text("MosIC Solutions Pvt Ltd — Confidential", pw - mr, fy, { align: "right" });

    // thin line above footer
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.3);
    doc.line(ml, fy - 3, pw - mr, fy - 3);
  };

  // ── Check remaining space, add page if needed ──────────────────────────────
  const ensureSpace = (needed: number) => {
    if (y + needed > ph - 18) {
      drawFooter();
      doc.addPage();
      pageNum++;
      drawHeader();
    }
  };

  // ── Section title ──────────────────────────────────────────────────────────
  const sectionTitle = (title: string) => {
    ensureSpace(10);
    doc.setFillColor(245, 247, 250);
    doc.rect(ml, y, cw, 7, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(40, 40, 40);
    doc.text(title.toUpperCase(), ml + 3, y + 5);
    y += 9;
  };

  // ── Key-value row ──────────────────────────────────────────────────────────
  const kvRow = (label: string, value: string, x = ml, w = cw / 2) => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(100, 100, 100);
    doc.text(`${label}:`, x + 2, y + 4.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(30, 30, 30);
    doc.text(fmt(value), x + 30, y + 4.5);
    y += 6.5;
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // PAGE 1
  // ═══════════════════════════════════════════════════════════════════════════
  drawHeader();

  // ── Document title bar ─────────────────────────────────────────────────────
  doc.setFillColor(30, 80, 160);
  doc.rect(ml, y, cw, 9, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text("FILE INDEX RECORD", pw / 2, y + 6.2, { align: "center" });
  y += 13;

  // ── File details section ───────────────────────────────────────────────────
  sectionTitle("File Details");

  // Two-column layout
  const col1x = ml;
  const col2x = ml + cw / 2 + 2;
  const colW  = cw / 2 - 2;

  // Row 1
  let rowY = y;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(100, 100, 100);
  doc.text("File ID:", col1x + 2, rowY + 4.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 30, 30);
  doc.text(fmt(file.id), col1x + 28, rowY + 4.5);

  doc.setFont("helvetica", "bold");
  doc.setTextColor(100, 100, 100);
  doc.text("File Date:", col2x + 2, rowY + 4.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 30, 30);
  doc.text(fmt(file.f_date), col2x + 28, rowY + 4.5);
  y += 7;

  // Row 2
  rowY = y;
  doc.setFont("helvetica", "bold");
  doc.setTextColor(100, 100, 100);
  doc.text("Activity:", col1x + 2, rowY + 4.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 30, 30);
  doc.text(fmt(file.f_activity), col1x + 28, rowY + 4.5);

  doc.setFont("helvetica", "bold");
  doc.setTextColor(100, 100, 100);
  doc.text("Status:", col2x + 2, rowY + 4.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 30, 30);
  const statusText = statusLabel(file.status);
  doc.setTextColor(statusText === "Active" ? 22 : 120, statusText === "Active" ? 120 : 120, statusText === "Active" ? 46 : 120);
  doc.text(statusText, col2x + 28, rowY + 4.5);
  doc.setTextColor(30, 30, 30);
  y += 7;

  // Row 3 — subject (full width)
  rowY = y;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(100, 100, 100);
  doc.text("Subject:", col1x + 2, rowY + 4.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 30, 30);
  const subjectLines = doc.splitTextToSize(fmt(file.f_subject), cw - 32);
  doc.text(subjectLines, col1x + 28, rowY + 4.5);
  y += Math.max(7, subjectLines.length * 5);

  // Row 4 — description (full width)
  rowY = y;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(100, 100, 100);
  doc.text("Description:", col1x + 2, rowY + 4.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 30, 30);
  const descLines = doc.splitTextToSize(fmt(file.f_description), cw - 32);
  doc.text(descLines, col1x + 28, rowY + 4.5);
  y += Math.max(7, descLines.length * 5);

  if (file.datecreated) {
    rowY = y;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(100, 100, 100);
    doc.text("Date Created:", col1x + 2, rowY + 4.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(30, 30, 30);
    doc.text(fmt(file.datecreated), col1x + 34, rowY + 4.5);
    y += 7;
  }

  // thin separator
  doc.setDrawColor(220, 220, 220);
  doc.setLineWidth(0.3);
  doc.line(ml, y, pw - mr, y);
  y += 6;

  // ── Activities section ─────────────────────────────────────────────────────
  sectionTitle(`Activities  (${activities.length} record${activities.length !== 1 ? "s" : ""})`);

  if (activities.length === 0) {
    doc.setFont("helvetica", "italic");
    doc.setFontSize(9);
    doc.setTextColor(140, 140, 140);
    doc.text("No activities recorded for this file.", ml + 3, y + 5);
    y += 10;
  } else {
    // Table config
    const cols = [
      { label: "#",        w: 10 },
      { label: "ID",       w: 16 },
      { label: "Date",     w: 28 },
      { label: "Remarks",  w: 72 },
      { label: "Attachment", w: 38 },
      { label: "Status",   w: 22 },
    ];

    const drawTableHeader = () => {
      ensureSpace(10);
      doc.setFillColor(30, 80, 160);
      doc.rect(ml, y, cw, 8, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(255, 255, 255);
      let cx = ml;
      cols.forEach((col) => {
        doc.text(col.label, cx + 2, y + 5.5);
        cx += col.w;
      });
      y += 8;
    };

    drawTableHeader();

    activities.forEach((act, idx) => {
      // estimate row height based on remarks length
      const remarkLines = doc.splitTextToSize(fmt(act.activityRemarks), cols[3].w - 4);
      const rowH = Math.max(8, remarkLines.length * 5 + 3);

      ensureSpace(rowH + 2);

      // Re-draw table header if we just added a new page
      // (ensureSpace already called drawHeader; check if we need col headers again)
      const isFirstRowOnPage = y <= 50; // just drew header
      if (isFirstRowOnPage && idx > 0) {
        drawTableHeader();
      }

      // Row fill (alternating)
      if (idx % 2 === 0) {
        doc.setFillColor(249, 250, 252);
        doc.rect(ml, y, cw, rowH, "F");
      }

      // Row border
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.2);
      doc.rect(ml, y, cw, rowH);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(40, 40, 40);

      let cx = ml;
      // #
      doc.text(String(idx + 1), cx + 2, y + 5);
      cx += cols[0].w;
      // ID
      doc.text(fmt(act.id), cx + 2, y + 5);
      cx += cols[1].w;
      // Date
      doc.text(fmt(act.activityDate), cx + 2, y + 5);
      cx += cols[2].w;
      // Remarks (multi-line)
      doc.text(remarkLines, cx + 2, y + 5);
      cx += cols[3].w;
      // Attachment
      const hasBlob = /^\d+$/.test((act.activityDocId || "").trim());
      doc.setTextColor(hasBlob ? 30 : 140, hasBlob ? 80 : 140, hasBlob ? 160 : 140);
      doc.text(hasBlob ? `Blob #${act.activityDocId}` : "—", cx + 2, y + 5);
      doc.setTextColor(40, 40, 40);
      cx += cols[4].w;
      // Status
      const sl = statusLabel(act.activityStatus);
      doc.setTextColor(
        sl === "Active" || sl === "Completed" ? 22 : sl === "Pending" ? 160 : 120,
        sl === "Active" || sl === "Completed" ? 120 : sl === "Pending" ? 100 : 120,
        sl === "Active" || sl === "Completed" ? 46  : sl === "Pending" ? 20  : 120,
      );
      doc.text(sl, cx + 2, y + 5);
      doc.setTextColor(40, 40, 40);

      y += rowH;
    });

    y += 4;
  }

  // ── Signature footer ───────────────────────────────────────────────────────
  ensureSpace(28);
  y += 6;
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.rect(ml, y, cw, 22);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(40, 40, 40);
  doc.text("FOR MOSIC SOLUTIONS PVT LTD", ml + 4, y + 6);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text("AUTHORISED SIGNATURE", ml + 4, y + 18);

  y += 26;

  // Final footer on last page
  drawFooter();

  // ── Save ───────────────────────────────────────────────────────────────────
  const filename = `File_${file.id}_${(file.f_subject || "record").replace(/[^a-zA-Z0-9]/g, "_").slice(0, 30)}.pdf`;
  doc.save(filename);
}