/**
 * generateEmpDetailsPDF.ts
 *
 * Generates a professional Employee Details PDF.
 * Layout (single page, A4):
 *   • Company logo + header (same as payslip)
 *   • Title: "EMPLOYEE DETAILS"
 *   • Sections: Personal Information / Contact & Address / Tax & Compliance / Bank Details
 *   • Authorised signatory footer
 *
 * Place this file at:  src/pages/pdf/generateEmpDetailsPDF.ts
 *
 * Usage:
 *   import { generateEmpDetailsPDF } from "../pdf/generateEmpDetailsPDF";
 *   generateEmpDetailsPDF(emp, position);
 */

import jsPDF from "jspdf";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface EmpDetailForPDF {
  id: number | null;
  empName: string;
  empLastName: string;
  empDob?: string;
  empDoj?: string;
  empPh?: string;
  empMail?: string;
  empEmail?: string;
  empPan?: string;
  empAdhar?: string;
  empAccNo?: string;
  empBankName?: string;
  empAccName?: string;
  empIfscCode?: string;
  empAddress1?: string;
  empAddress2?: string;
  empAddress3?: string;
  status?: string;
}

export interface EmpPositionDetailForPDF {
  position?: string;
  department?: string;
  role?: string;
  empBasic?: string;
  empHra?: string;
  empAllowance?: string;
  empMonthGross?: string;
  epDate?: string;
  epEfficientDate?: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmtDate = (d: string | undefined | null): string => {
  if (!d) return "—";
  const parts = d.includes("-") ? d.split("-") : d.split("/");
  if (parts.length !== 3) return d;
  if (parts[0].length === 2) return d; // already DD-MM-YYYY
  const [y, m, day] = parts;
  return `${day}-${m}-${y}`;
};

const val = (v: string | undefined | null): string => v?.trim() || "—";

// ─── Section renderer ─────────────────────────────────────────────────────────

function drawSectionHeader(
  doc: jsPDF,
  title: string,
  x: number,
  y: number,
  width: number,
): number {
  doc.setFillColor(30, 64, 175); // brand blue
  doc.rect(x, y, width, 7, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(255, 255, 255);
  doc.text(title.toUpperCase(), x + 3, y + 5);
  return y + 7;
}

function drawRow(
  doc: jsPDF,
  label: string,
  value: string,
  x: number,
  y: number,
  colWidth: number,
  rowHeight: number,
  shade: boolean,
): number {
  if (shade) {
    doc.setFillColor(248, 250, 252);
    doc.rect(x, y, colWidth * 2, rowHeight, "F");
  }
  // Border
  doc.setDrawColor(220, 220, 220);
  doc.setLineWidth(0.2);
  doc.rect(x, y, colWidth * 2, rowHeight);
  doc.line(x + colWidth, y, x + colWidth, y + rowHeight);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(80, 80, 80);
  doc.text(label, x + 2, y + rowHeight / 2 + 1.5);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(20, 20, 20);
  doc.text(value, x + colWidth + 2, y + rowHeight / 2 + 1.5);

  return y + rowHeight;
}

// ─── Main export ─────────────────────────────────────────────────────────────

export function generateEmpDetailsPDF(
  emp: EmpDetailForPDF,
  position?: EmpPositionDetailForPDF,
): void {
  const doc  = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw   = doc.internal.pageSize.getWidth();
  const ml   = 14;
  const mr   = pw - ml;
  const tableW = mr - ml;
  const colW   = tableW / 2;
  const rowH   = 8;

  // ── Logo placeholder ───────────────────────────────────────────────────────
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.rect(ml, 8, 36, 28);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7);
  doc.setTextColor(160, 160, 160);
  doc.text("LOGO", ml + 11, 23);

  // ── Company header ─────────────────────────────────────────────────────────
  const cx = ml + 40;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(20, 20, 20);
  doc.text("MosIC Solutions Pvt Ltd", cx, 17);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(40, 40, 40);
  doc.text("No 5 Second A Cross Rajashree Layout,Munnekolala,Marathahalli,", cx, 23);
  doc.text("Bangalore 560037",                  cx, 28);
  doc.text("Karnataka",                         mr, 28, { align: "right" });
  doc.text("GST No: 29AAICM6836G1Z3",           cx, 33);
  doc.text("PAN No:AAICM6836G",                 mr, 33, { align: "right" });
  doc.text("CIN No:U72200KA2013PTC069886",       cx, 38);
  doc.text("Website:www.mosics.com",            mr, 38, { align: "right" });
  doc.text("Phone: +91-9980914698",             cx, 43);
  doc.text("Email: salesandsupport@mosics.com", mr, 43, { align: "right" });

  // ── Top rule ───────────────────────────────────────────────────────────────
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(1.5);
  doc.line(ml, 50, mr, 50);

  // ── Title ─────────────────────────────────────────────────────────────────
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(20, 20, 20);
  doc.text("EMPLOYEE DETAILS", pw / 2, 57, { align: "center" });

  doc.setLineWidth(1.5);
  doc.line(ml, 61, mr, 61);

  // ── Emp ID + Name banner ───────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text(
    `Employee ID: ${emp.id ?? "—"}   |   Name: ${emp.empName} ${emp.empLastName}   |   Status: ${emp.status === "1" ? "Active" : "Inactive"}`,
    pw / 2, 67, { align: "center" },
  );

  doc.setLineWidth(0.5);
  doc.line(ml, 71, mr, 71);

  let y = 76;

  // ─────────────────────────────────────────────────────────────────────────
  // SECTION 1 — Personal Information
  // ─────────────────────────────────────────────────────────────────────────
  y = drawSectionHeader(doc, "Personal Information", ml, y, tableW);

  const personalRows: [string, string][] = [
    ["First Name",      val(emp.empName)],
    ["Last Name",       val(emp.empLastName)],
    ["Date of Birth",   fmtDate(emp.empDob)],
    ["Date of Joining", fmtDate(emp.empDoj)],
    ["Designation",     val(position?.position)],
    ["Department",      val(position?.department)],
    ["Role",            val(position?.role)],
  ];

  personalRows.forEach(([label, value], i) => {
    y = drawRow(doc, label, value, ml, y, colW, rowH, i % 2 === 1);
  });

  y += 4;

  // ─────────────────────────────────────────────────────────────────────────
  // SECTION 2 — Contact & Address
  // ─────────────────────────────────────────────────────────────────────────
  y = drawSectionHeader(doc, "Contact & Address", ml, y, tableW);

  const contactRows: [string, string][] = [
    ["Phone",      val(emp.empPh)],
    ["Email",      val(emp.empMail ?? emp.empEmail)],
    ["Address 1",  val(emp.empAddress1)],
    ["Address 2",  val(emp.empAddress2)],
    ["Address 3",  val(emp.empAddress3)],
  ];

  contactRows.forEach(([label, value], i) => {
    y = drawRow(doc, label, value, ml, y, colW, rowH, i % 2 === 1);
  });

  y += 4;

  // ─────────────────────────────────────────────────────────────────────────
  // SECTION 3 — Tax & Compliance
  // ─────────────────────────────────────────────────────────────────────────
  y = drawSectionHeader(doc, "Tax & Compliance", ml, y, tableW);

  // Mask Aadhaar: show only last 4 digits
  const aadhaar = emp.empAdhar?.trim()
    ? `XXXX-XXXX-${emp.empAdhar.slice(-4)}`
    : "—";

  const taxRows: [string, string][] = [
    ["PAN Number",    val(emp.empPan)],
    ["Aadhaar",       aadhaar],
  ];

  taxRows.forEach(([label, value], i) => {
    y = drawRow(doc, label, value, ml, y, colW, rowH, i % 2 === 1);
  });

  y += 4;

  // ─────────────────────────────────────────────────────────────────────────
  // SECTION 4 — Bank Details
  // ─────────────────────────────────────────────────────────────────────────
  y = drawSectionHeader(doc, "Bank Details", ml, y, tableW);

  // Mask account number: show only last 4 digits
  const accNo = emp.empAccNo?.trim()
    ? `${"X".repeat(Math.max(0, emp.empAccNo.length - 4))}${emp.empAccNo.slice(-4)}`
    : "—";

  const bankRows: [string, string][] = [
    ["Account Holder Name", val(emp.empAccName)],
    ["Bank Name",           val(emp.empBankName)],
    ["Account Number",      accNo],
    ["IFSC Code",           val(emp.empIfscCode)],
  ];

  bankRows.forEach(([label, value], i) => {
    y = drawRow(doc, label, value, ml, y, colW, rowH, i % 2 === 1);
  });

  // ─────────────────────────────────────────────────────────────────────────
  // SECTION 5 — Salary Information (if position provided)
  // ─────────────────────────────────────────────────────────────────────────
  if (position) {
    y += 4;
    y = drawSectionHeader(doc, "Current Salary Details", ml, y, tableW);

    const num = (v: unknown) => parseFloat(String(v ?? 0)) || 0;
    const fmt = (v: unknown) => `₹ ${num(v).toLocaleString("en-IN", { minimumFractionDigits: 2 })}`;

    const salaryRows: [string, string][] = [
      ["Basic / Fixed Pay",  fmt(position.empBasic)],
      ["HRA",                fmt(position.empHra)],
      ["Other Allowances",   fmt(position.empAllowance)],
      ["Monthly Gross",      fmt(position.empMonthGross)],
      ["Effective From",     fmtDate(position.epEfficientDate ?? position.epDate)],
    ];

    salaryRows.forEach(([label, value], i) => {
      y = drawRow(doc, label, value, ml, y, colW, rowH, i % 2 === 1);
    });
  }

  // ── Bottom rule ────────────────────────────────────────────────────────────
  y += 10;
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(0.5);
  doc.line(ml, y, mr, y);

  // ── Generated timestamp ────────────────────────────────────────────────────
  y += 5;
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7.5);
  doc.setTextColor(130, 130, 130);
  const now = new Date();
  doc.text(
    `Generated on ${now.toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })} at ${now.toLocaleTimeString("en-IN")}`,
    ml, y,
  );

  // ── Authorised signatory ───────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(20, 20, 20);
  doc.text("With Regards", mr - 50, y + 8);
  doc.text("(Authorised Signatory)", mr - 50, y + 20);

  // ── Save ──────────────────────────────────────────────────────────────────
  doc.save(`EMP_DETAILS_${emp.id}_${emp.empName}_${emp.empLastName}.pdf`);
}