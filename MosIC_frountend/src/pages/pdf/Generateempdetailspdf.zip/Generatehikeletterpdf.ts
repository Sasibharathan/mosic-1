/**
 * generateHikeLetterPDF.ts
 *
 * Generates a Pay Hike Letter PDF.
 * Matches the exact layout of PDFDESIGN_HIKELETTER.java output.
 *
 * Layout (single page, A4):
 *   • Top-left  : Company logo placeholder
 *   • Top-right : Company name (large) + address two-column
 *   • Thick horizontal separator lines
 *   • "PAY HIKE FOR MONTH OF - <MONTH>-<YEAR>" banner (centred, between lines)
 *   • Left column : REF NO / TO / employee address
 *   • Right column: DATE / DESIGNATION / EMAIL / CURRENCY
 *   • DEAR paragraph
 *   • Payment table: FIXED PAY / HRA / OTHER ALLOWANCE (blue text)
 *                    blank row + Gross Annual Salary (black)
 *   • Implementation note + "With Regards" + "(Authorised signatory)"
 *
 * Usage:
 *   import { generateHikeLetterPDF } from "./pdf/generateHikeLetterPDF";
 *   generateHikeLetterPDF(row, emp, payMonth, payYear, letterDate);
 */

import jsPDF from "jspdf";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface EmpPositionDTO {
  id: number | null;
  empId: number | null;
  epDate: string;
  epEfficientDate: string;
  position: string;
  department: string;
  role: string;
  reportingTo: string;
  empBasic: string;
  empHra: string;
  empAllowance: string;
  empMonthGross: string;
  empCtc: string;
  empTds: string;
  empPt: string;
  empLoans: string;
  activeStatus: string;
  status: string;
}

export interface EmpDTO {
  id: number;
  empName: string;
  empLastName: string;
  empEmail?: string;
  empPhone?: string;
  empMail?: string;
  empPh?: string;
  empAddress1?: string;
  empAddress2?: string;
  empAddress3?: string;
  empDoj?: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const fmtDate = (d: string | undefined | null): string => {
  if (!d) return "";
  const parts = d.includes("-") ? d.split("-") : d.split("/");
  if (parts.length !== 3) return d;
  if (parts[0].length === 2) return d;
  const [y, m, day] = parts;
  return `${day}-${m}-${y}`;
};

const num = (v: unknown): number => parseFloat(String(v ?? 0)) || 0;
const cur = (v: unknown): string => num(v).toFixed(2);

const MONTH_NAMES = [
  "", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
  "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER",
];

// ─── Main export ──────────────────────────────────────────────────────────────

/**
 * @param row         EmpPositionDTO
 * @param emp         EmpDTO
 * @param payMonth    "1"–"12" (optional, used in banner title)
 * @param payYear     "2025" etc. (optional)
 * @param letterDate  ISO yyyy-mm-dd for DATE field; defaults to today
 */
export function generateHikeLetterPDF(
  row: EmpPositionDTO,
  emp: EmpDTO,
  payMonth?: string,
  payYear?: string,
  letterDate?: string,
): void {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw  = doc.internal.pageSize.getWidth();
  const ph  = doc.internal.pageSize.getHeight();
  const ml  = 15;
  const right = pw - ml;

  // Derived values
  const date    = fmtDate(letterDate) || (() => {
    const n = new Date();
    return `${String(n.getDate()).padStart(2,"0")}-${String(n.getMonth()+1).padStart(2,"0")}-${n.getFullYear()}`;
  })();
  const effDate = fmtDate(row.epEfficientDate || row.epDate) || date;
  const refNo   = `PYHK/LTR/${effDate}/${row.empId ?? emp.id}`;

  const monthLabel = payMonth
    ? `${MONTH_NAMES[parseInt(payMonth, 10)] ?? payMonth}-${payYear ?? ""}`
    : "";

  const basic     = cur(row.empBasic);
  const hra       = cur(row.empHra);
  const allowance = cur(row.empAllowance);
  const gross     = cur(row.empMonthGross);

  const addr = [emp.empAddress1, emp.empAddress2, emp.empAddress3].filter(Boolean) as string[];
  const email = emp.empMail ?? emp.empEmail ?? "";

  // ── Logo box ───────────────────────────────────────────────────────────────
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.4);
  doc.rect(ml, 8, 38, 30);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7);
  doc.setTextColor(160, 160, 160);
  doc.text("LOGO", ml + 12, 25);

  // ── Company header ─────────────────────────────────────────────────────────
  const cx = ml + 42;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(20, 20, 20);
  doc.text("MosIC Solutions Pvt Ltd", cx, 18);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(40, 40, 40);
  doc.text("No 5 Second A Cross Rajashree Layout,Munnekolala,Marathahalli,", cx, 24);
  doc.text("Bangalore 560037",               cx,    30);
  doc.text("Karnataka",                      right, 30, { align: "right" });
  doc.text("GST No: 29AAICM6836G1Z3",        cx,    36);
  doc.text("PAN No:AAICM6836G",              right, 36, { align: "right" });
  doc.text("CIN No:U72200KA2013PTC069886",   cx,    42);
  doc.text("Website:www.mosics.com",         right, 42, { align: "right" });
  doc.text("Phone: +91-9980914698",          cx,    48);
  doc.text("Email: salesandsupport@mosics.com", right, 48, { align: "right" });

  // ── Top horizontal rule ────────────────────────────────────────────────────
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(1.5);
  doc.line(ml, 56, right, 56);

  // ── Banner title ───────────────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(14);
  doc.setTextColor(20, 20, 20);
  const bannerText = monthLabel
    ? `PAY HIKE FOR MONTH OF - ${monthLabel}`
    : "PAY HIKE LETTER";
  doc.text(bannerText, pw / 2, 64, { align: "center" });

  // ── Bottom rule of banner ──────────────────────────────────────────────────
  doc.setLineWidth(1.5);
  doc.line(ml, 68, right, 68);

  // ── REF NO ────────────────────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text(`REF NO: ${refNo}`, ml, 76);

  // ── TO (left column) ──────────────────────────────────────────────────────
  let ly = 82;                    // left-column y cursor
  doc.setFontSize(9);
  doc.text("TO", ml, ly); ly += 6;
  doc.text(`${emp.empName} ${emp.empLastName},`, ml, ly); ly += 6;
  addr.forEach((line) => {
    doc.text(`${line},`, ml, ly);
    ly += 6;
  });

  // ── Right meta block (DATE / DESIGNATION / EMAIL / CURRENCY) ──────────────
  // These are drawn at fixed y positions matching the Java right-column layout
  const ry0 = 82;                 // DATE row
  const labelX = right - 60;     // label start
  const valueX = right;          // value right-aligned

  const metaRows: [string, string][] = [
    ["DATE :",        date],
    ["DESIGNATION :", row.position || ""],
    ["EMAIL :",       email],
    ["CURRENCY :",    "INR"],
  ];

  doc.setFontSize(9);
  metaRows.forEach(([label, value], i) => {
    const ry = ry0 + i * 6;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(60, 60, 60);
    doc.text(label, labelX, ry);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(20, 20, 20);
    doc.text(value, valueX, ry, { align: "right" });
  });

  // ── DEAR paragraph ────────────────────────────────────────────────────────
  // Start below whichever is lower: left-column bottom or right-column bottom
  const bodyStartY = Math.max(ly, ry0 + metaRows.length * 6) + 6;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text(`DEAR ${emp.empName},`, ml, bodyStartY);

  const para1y = bodyStartY + 7;
  doc.text(
    "We are pleased to communicate to you that based on the Performance appraisal your salary",
    ml + 8, para1y,
  );
  // Java prints "is <NETSalary>" on the next indented line
  const netSalary = num(row.empMonthGross) - (num(row.empTds) + num(row.empPt) + num(row.empLoans));
  doc.text(`is ${netSalary.toFixed(1)}`, ml + 8, para1y + 6);
  doc.text("revised and the new monthly salary is as follows", ml + 8, para1y + 12);

  // ── "Payment" sub-heading ─────────────────────────────────────────────────
  const tableHeadY = para1y + 22;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text("Payment", ml + 12, tableHeadY);

  // ── Salary table ──────────────────────────────────────────────────────────
  // Mirrors the Java blue-text rows + black Gross row exactly
  // Each row: label at x=ml+20, value right-aligned at x=right-12
  // After each row a thin blue horizontal rule is drawn

  const tableX   = ml + 12;
  const tableValX = right - 12;
  const rowStep  = 14;           // vertical spacing between rows (Java ~15pt)

  interface SalRow { label: string; value: string; isBlue: boolean; }
  const salaryRows: SalRow[] = [
    { label: "FIXED PAY",       value: basic,     isBlue: true  },
    { label: "HRA",             value: hra,       isBlue: true  },
    { label: "OTHER ALLOWANCE", value: allowance, isBlue: true  },
    { label: "",                value: "",        isBlue: true  },  // blank separator row
    { label: "Grpss Annual Salary", value: gross, isBlue: false },  // 'Grpss' matches original
  ];

  let ty = tableHeadY + 8;
  salaryRows.forEach(({ label, value, isBlue }) => {
    if (label) {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      doc.setTextColor(isBlue ? 0 : 20, isBlue ? 0 : 20, isBlue ? 255 : 20);
      // Original uses Color.BLUE for label+value on first 3 rows, black for gross
      if (isBlue) {
        doc.setTextColor(0, 0, 200);
      } else {
        doc.setTextColor(20, 20, 20);
      }
      doc.text(label, tableX + 8, ty);
      doc.text(value, tableValX, ty, { align: "right" });
    }
    // Thin blue horizontal rule below each row (including blank row)
    doc.setDrawColor(0, 0, 200);
    doc.setLineWidth(0.4);
    doc.line(tableX, ty + 3, tableValX + 12, ty + 3);
    ty += rowStep;
  });

  // ── Implementation note ───────────────────────────────────────────────────
  const noteY = ty + 4;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text(
    `New salary will be implemented from ${effDate}  till further communication on salary revision.`,
    ml + 8, noteY, { maxWidth: pw - ml * 2 - 16 },
  );

  // ── "With Regards" ────────────────────────────────────────────────────────
  doc.text("With Regards", ml + 8, noteY + 12);

  // ── "(Authorised signatory)" ──────────────────────────────────────────────
  // Positioned well below "With Regards" to leave space for physical signature
  doc.text("(Authorised signatory)", ml + 8, noteY + 50);

  // ── Save ─────────────────────────────────────────────────────────────────
  doc.save(
    `${Date.now()}-HIKELETTER_${emp.id}_${emp.empName}_${emp.empLastName}.pdf`,
  );
}