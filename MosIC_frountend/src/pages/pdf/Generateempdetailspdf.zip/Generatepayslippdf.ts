/**
 * generatePayslipPDF.ts
 *
 * Generates a Payslip PDF matching the PAYSLIP.pdf design:
 *   • Company logo (top-left) + Company header (top-right two-column)
 *   • Thick separator lines around "PAYSLIP FOR MONTH OF - <MONTH>-<YEAR>"
 *   • Left meta: EMPLOYEE ID / PAN CARD NO / PAYSLIP REF / EMPLOYEE NAME
 *   • Right meta: DATE / DESIGNATION / EMAIL
 *   • Three-column table: PAYMENTS | DEDUCTIONS | BANK DETAILS
 *   • Footer row: GROSS RS. | DEDUCTIONS RS. | NET SALARY RS.
 *
 * Place this file at:  src/pages/pdf/generatePayslipPDF.ts
 *
 * Usage:
 *   import { generatePayslipPDF } from "../pdf/generatePayslipPDF";
 *   generatePayslipPDF(payslip, emp, position);
 */

import jsPDF from "jspdf";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface PayslipForPDF {
  id: number | null;
  empId: number | null;
  empMonth: string;       // "01"–"12"
  empYear: string;        // "2025"
  basic: string;
  hra: string;
  allowancess: string;
  totalGross: string;
  tds: string;
  pt: string;
  loan: string;
  totalDeduction: string;
  status: number;
}

export interface EmpForPDF {
  id: number | null;
  empName: string;
  empLastName: string;
  empMail?: string;
  empEmail?: string;
  empPan?: string;
  empAccNo?: string;
  empBankName?: string;
  empIfscCode?: string;
  empAccName?: string;
}

export interface PositionForPDF {
  position?: string;
  department?: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const MONTH_NAMES = [
  "", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
  "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER",
];

const num = (v: unknown): number => parseFloat(String(v ?? 0)) || 0;

// ─── Main export ─────────────────────────────────────────────────────────────

export function generatePayslipPDF(
  payslip: PayslipForPDF,
  emp: EmpForPDF,
  position?: PositionForPDF,
): void {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pw   = doc.internal.pageSize.getWidth();   // 210
  const ml   = 14;
  const mr   = pw - ml;                             // 196

  // ── Derived values ─────────────────────────────────────────────────────────
  const monthNum   = parseInt(payslip.empMonth, 10);
  const monthName  = MONTH_NAMES[monthNum] ?? payslip.empMonth;
  const monthLabel = `${monthName}-${payslip.empYear}`;

  // Recompute from individual fields — stored totals may be stale or blank.
  const basic      = num(payslip.basic);
  const hra        = num(payslip.hra);
  const allowances = num(payslip.allowancess);
  const tds        = num(payslip.tds);
  const pt         = num(payslip.pt);
  const loan       = num(payslip.loan);

  const gross      = num(payslip.totalGross)     || (basic + hra + allowances);
  const deductions = num(payslip.totalDeduction) || (tds + pt + loan);
  const net        = gross - deductions;
  const email       = emp.empMail ?? emp.empEmail ?? "";
  const fullName    = `${emp.empName} ${emp.empLastName}`.trim();
  const today       = new Date();
  const dateStr     = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")} ${String(today.getHours()).padStart(2, "0")}:${String(today.getMinutes()).padStart(2, "0")}:${String(today.getSeconds()).padStart(2, "0")}`;

  // ── Logo placeholder ───────────────────────────────────────────────────────
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.rect(ml, 8, 36, 28);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7);
  doc.setTextColor(160, 160, 160);
  doc.text("LOGO", ml + 11, 23);

  // ── Company header ─────────────────────────────────────────────────────────
  const cx = ml + 40;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(20, 20, 20);
  doc.text("MosIC Solutions Pvt Ltd", cx, 17);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(40, 40, 40);
  doc.text("No 5 Second A Cross Rajashree Layout,Munnekolala,Marathahalli,", cx, 23);
  doc.text("Bangalore 560037",               cx,    28);
  doc.text("Karnataka",                      mr,    28, { align: "right" });
  doc.text("GST No: 29AAICM6836G1Z3",        cx,    33);
  doc.text("PAN No:AAICM6836G",              mr,    33, { align: "right" });
  doc.text("CIN No:U72200KA2013PTC069886",   cx,    38);
  doc.text("Website:www.mosics.com",         mr,    38, { align: "right" });
  doc.text("Phone: +91-9980914698",          cx,    43);
  doc.text("Email: salesandsupport@mosics.com", mr, 43, { align: "right" });

  // ── Separator + title ──────────────────────────────────────────────────────
  doc.setDrawColor(20, 20, 20);
  doc.setLineWidth(1.5);
  doc.line(ml, 50, mr, 50);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(20, 20, 20);
  doc.text("PAYSLIP", pw / 2, 57, { align: "center" });

  doc.setLineWidth(1.5);
  doc.line(ml, 61, mr, 61);

  // ── Banner: PAYSLIP FOR MONTH OF ──────────────────────────────────────────
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text(`PAYSLIP FOR MONTH OF-   ${monthLabel}`, pw / 2, 68, { align: "center" });

  doc.setLineWidth(1.5);
  doc.line(ml, 72, mr, 72);

  // ── Left meta block ────────────────────────────────────────────────────────
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(20, 20, 20);
  const lx = ml + 2;
  doc.text(`EMPLOYEE ID :   ${emp.id ?? ""}`,        lx, 79);
  doc.text(`PAN CARD NO :   ${emp.empPan ?? ""}`,    lx, 85);
  doc.text(`PAYSLIP REF :   ${payslip.id ?? ""}`,    lx, 91);
  doc.text(`EMPLOYEE NAME :   ${fullName}`,          lx, 97);

  // ── Right meta block ───────────────────────────────────────────────────────
  const rx = mr;
  doc.text(`DATE: ${dateStr}`,                       rx, 79, { align: "right" });
  doc.text(`DESIGNATION: ${position?.position ?? ""}`, rx, 85, { align: "right" });
  doc.text(`EMAIL: ${email}`,                        rx, 91, { align: "right" });

  // ── Three-column table ─────────────────────────────────────────────────────
  // Column widths: 60 | 60 | 76 = 196
  const colW   = [60, 60, 76];
  const tableX = ml;
  const tableY = 103;
  const rowH   = 7;

  // Header row
  const headerCols = ["PAYMENTS", "DEDUCTIONS", "BANK DETAILS"];
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);

  let cx2 = tableX;
  headerCols.forEach((h, i) => {
    doc.setFillColor(230, 230, 230);
    doc.rect(cx2, tableY, colW[i], rowH, "FD");
    doc.text(h, cx2 + colW[i] / 2, tableY + 5, { align: "center" });
    cx2 += colW[i];
  });

  // Data rows — PAYMENTS | DEDUCTIONS | BANK DETAILS
  const fmt = (n: number) => n.toLocaleString("en-IN", { minimumFractionDigits: 2 });
  const payRows = [
    [`FIXED PAY   ${fmt(basic)}`,      `PROFESSIONAL TAX   ${fmt(pt)}`,   emp.empAccNo ?? ""],
    [`HRA   ${fmt(hra)}`,              `TDS DEDUCTIONS   ${fmt(tds)}`,    `BANK ACCOUNT NO`],
    [`ALLOWANCES   ${fmt(allowances)}`,`OTHER DEDUCTIONS   ${fmt(loan)}`, emp.empIfscCode ?? ""],
    ["", "", "BANK BRANCH IFSC CODE"],
    ["", "", emp.empBankName ?? ""],
  ];

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(20, 20, 20);

  payRows.forEach((row, ri) => {
    let cx3 = tableX;
    row.forEach((cell, ci) => {
      const y = tableY + rowH + ri * rowH;
      doc.setDrawColor(200, 200, 200);
      doc.setLineWidth(0.3);
      doc.rect(cx3, y, colW[ci], rowH);
      doc.text(cell, cx3 + 2, y + 5);
      cx3 += colW[ci];
    });
  });

  // ── Footer row: GROSS | DEDUCTIONS | NET ──────────────────────────────────
  const footerY = tableY + rowH + payRows.length * rowH;
  const fmt2 = (n: number) => n.toLocaleString("en-IN", { minimumFractionDigits: 2 });
  const footerData = [
    `GROSS RS.   ${fmt2(gross)}`,
    `DEDUCTIONS RS.   ${fmt2(deductions)}`,
    `NET SALARY RS.   ${fmt2(net)}`,
  ];

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(20, 20, 20);

  let fx = tableX;
  footerData.forEach((cell, i) => {
    doc.setFillColor(240, 240, 240);
    doc.rect(fx, footerY, colW[i], rowH, "FD");
    doc.text(cell, fx + 2, footerY + 5);
    fx += colW[i];
  });

  // ── Save ──────────────────────────────────────────────────────────────────
  doc.save(
    `PAYSLIP_${emp.id}_${emp.empName}_${emp.empLastName}_${monthLabel}.pdf`,
  );
}